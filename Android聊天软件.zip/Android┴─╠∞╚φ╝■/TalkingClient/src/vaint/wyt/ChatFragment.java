package vaint.wyt;

import java.util.List;

import vaint.wyt.bean.ChatListModel;
import vaint.wyt.bean.User;
import vaint.wyt.constant.Constants;
import vaint.wyt.db.DataUtils;
import vaint.wyt.msg.MsgUtils;
import vaint.wyt.view.ChatListAdapter;
import vaint.wyt.view.ViewUtils;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.ListFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ListView;

public class ChatFragment extends ListFragment{
//	private static final String TAG = ChatFragment.class.getSimpleName();
	
	private Context mContext;
	private View mView;
	private ChatListAdapter mAdapter;
	
	private List<ChatListModel> mSourceDateList;
	
	Handler mHandler = new Handler();
	
	/**更新聊天列表的广播*/
	private BroadcastReceiver mBroadcast;
	
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mContext = getActivity();
		
		//注册更新聊天列表的广播
		mBroadcast = new MsgBroadcastReceiver();
		IntentFilter intentFilter = new IntentFilter();
		intentFilter.addAction(Constants.Actions.CHAT_LIST);
		mContext.registerReceiver(mBroadcast, intentFilter);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		mView = inflater.inflate(R.layout.layout_main_chat, container, false);
		return mView;
	}
	
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		//获取聊天列表
		mSourceDateList = DataUtils.GetChatList();
		mAdapter = new ChatListAdapter(mContext, mSourceDateList);
		setListAdapter(mAdapter);
		
		//设置长按监听,用于删除item
		getListView().setOnItemLongClickListener(new ItemLongClickListener());
	}
	
	@Override
	public void onResume() {
		super.onResume();
		//从聊天界面回到该界面时，需要更新列表显示。会话位置，聊天简要，时间
		updateChatList();
		
		//获取聊天列表
//		mSourceDateList = DataUtils.GetChatList();
//		mAdapter = new ChatListAdapter(mContext, mSourceDateList);
//		setListAdapter(mAdapter);
		
		//存储当前广播名 回到聊天列表界面，则恢复广播
		MsgUtils.SetCurrBroadCast(Constants.Actions.CHAT_LIST);
	}
	
	@Override
	public void onPause() {
		super.onPause();
		//清除当前广播名 离开聊天列表界面，则暂停广播
		MsgUtils.ClearCurrBroadCast();
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		if(mBroadcast!=null)
			mContext.unregisterReceiver(mBroadcast);
	}

	@Override
	public void onListItemClick(ListView listView, View view, int position, long id) {
		super.onListItemClick(listView, view, position, id);
		Intent intent = new Intent(mContext, ChattingActivity.class);
		
		Adapter adapter = listView.getAdapter();
		ChatListModel model = (ChatListModel) adapter.getItem(position);
		User friend = new User();
		friend.setUserId(model.getFriendId());
		friend.setName(model.getTitle());
		friend.setPhoto(ViewUtils.DrawableToString(model.getPhoto()));
		
		//如果这个会话有未读消息，则需要重置
		if(model.getUnread() > 0)
		{
			model.setUnread(0);
			//更新聊天列表数据
			mSourceDateList = DataUtils.UpdateChatList(model.getFriendId(), model);
			mAdapter.updateListView(mSourceDateList);
		}
		
		intent.putExtra(Constants.Flags.CHATTING_FRIEND, friend);
		startActivity(intent);
	}
	
	/**更新聊天列表*/
	public void updateChatList()
	{
		//这种做法，会出现头像错乱，还没有找到原因。
		mSourceDateList = DataUtils.GetChatList();
		mAdapter.updateListView(mSourceDateList);
		
//		mSourceDateList = DataUtils.GetChatList();
//		mAdapter = new ChatListAdapter(mContext, mSourceDateList);
//		setListAdapter(mAdapter);
	}
	
	/**更新聊天列表的广播*/
	class MsgBroadcastReceiver extends BroadcastReceiver
	{
		@Override
		public void onReceive(Context ctx, Intent intent) {
			updateChatList();
		}
	}
	
	class ItemLongClickListener implements OnItemLongClickListener{
		@Override
		public boolean onItemLongClick(AdapterView<?> arg0, View view,
				final int position, long arg3) {
			// 删除聊天会话
			new AlertDialog.Builder(mContext)
					.setMessage(R.string.dialog_msg_clear_chatting)
					.setNegativeButton(R.string.btn_cancel, null)
					.setPositiveButton(R.string.btn_ok,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface arg0,
										int arg1) {

									String friendId = mSourceDateList.get(position).getFriendId();
									//从聊天列表中删除对应会话,以及对应聊天记录
									DataUtils.RemoveChat(friendId);
									
									updateChatList();
								}
							}).show();
			return false;
		}
		
	}
}
