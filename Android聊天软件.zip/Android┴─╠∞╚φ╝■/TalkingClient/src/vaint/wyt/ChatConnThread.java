package vaint.wyt;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import vaint.wyt.bean.ChatData;
import vaint.wyt.constant.Constants;
import vaint.wyt.db.CacheUtils;
import vaint.wyt.msg.MsgUtils;
import vaint.wyt.msg.TipsUtils;

import android.content.Context;
import android.util.Log;

/**
 * 聊天通信线程
 * @author Vaint
 * @E-mail vaintwyt@163.com
 *
 */
public class ChatConnThread extends Thread{
	private static final String TAG = ChatConnThread.class.getSimpleName();
	private Context mContext;
	private Socket socket;
	//输入输出流保持唯一，不要多次创建，避免错误
	private ObjectOutputStream out;
	private ObjectInputStream in;
	
	/**线程运行终止标识*/
	private volatile boolean flag = true;
	
	public ChatConnThread(Context ctx)
	{
		mContext = ctx;
	}
	
	/**发送消息*/
	public void sendMsg(ChatData.MSG msg) {
		try {
			//检查是否断开连接
			checkConnSocket();
			out.writeObject(msg);// 发送消息
			out.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void run() {
		//接收消息
		while(flag)
		{
			try {
				//如果socket已经关闭，则需要重新连接
				checkConnSocket();
				Object obj =  in.readObject();
				
				if(obj instanceof ChatData.MSG)//聊天消息或添加好友请求
				{
					//通知栏提示
					TipsUtils.MsgNotificaction();
					ChatData.MSG msg = (ChatData.MSG)obj;
					
					switch (msg.getType()) {
					case CHATTING:
						//显示消息
						MsgUtils.ShowChattingMsg(mContext, msg);
						break;
						
					case ADD_FRIEND:
						//显示好友请求消息
						MsgUtils.ShowAddFriendMsg(mContext, msg);
						break;
						
					case ADD_AGREE:
						//更新好友列表
						MsgUtils.AddNewFriend(mContext, msg);
						break;
						
					}
				}
				
				Thread.sleep(250);
			} catch (Exception e) {
				e.printStackTrace();
				//关闭Socket,让其重新连接
				closeSocket();
			} 
		}
		
		//线程结束，关闭Socket
		closeSocket();
		
		Log.d(TAG,  " 连接线程已经关闭");
	}
	
	/**关闭Socket连接*/
	private void closeSocket()
	{
		try {
			if(socket != null)
			{
				out.close();
				in.close();
				socket.close();
				
				socket = null;
				Log.d(TAG,  "关闭Socket");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**检查连接，如果断开需要重新连接*/
	public synchronized void checkConnSocket()
	{
		while( flag && !isOnLine())
		{
			try {
				Log.d(TAG, CacheUtils.GetUserId() + " 创建连接");
				socket = new Socket(Constants.SERVER_IP, Constants.SERVER_PORT);
				socket.setKeepAlive(true);
				out = new ObjectOutputStream(socket.getOutputStream());
				
				//通过ID号建立与服务器的连接
				ChatData.ID id = new ChatData.ID();
				id.setUserId(CacheUtils.GetUserId());
				Log.d(TAG, "发送连接聊天服务的请求");
				out.writeObject(id);
				out.flush();
				
				//输入流的创建要在输出流写过数据之后。不然服务器和客户端都会阻塞
				in = new ObjectInputStream(socket.getInputStream());
				
				Thread.sleep(250);
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	/**关闭连接线程*/
	public void closeConn()
	{
		flag = false;
	}
	
	/**判断客户端连接*/
	public boolean isOnLine()
	{
		if(socket==null)
			return false;
		
		boolean ret = true;
		try{
			/*
			 * 发送测试数据
			 * 往输出流发送一个字节的数据，只要对方Socket的SO_OOBINLINE属性没有打开，
			 * 就会自动舍弃这个字节，而SO_OOBINLINE属性默认情况下就是关闭的
			 */
			//心跳测试
		    socket.sendUrgentData(0xFF);
		}catch(Exception e){
			Log.d(TAG, CacheUtils.GetUserId()+"连接已经断开了");
			ret = false;
			closeSocket();
		}
		
		return ret;
	}
}
