package vaint.wyt.encrypt;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import javax.crypto.Cipher;

import org.bouncycastle.jce.provider.BouncyCastleProvider;

import Decoder.BASE64Decoder;
import Decoder.BASE64Encoder;

/**
 * 加密工具类
 * 
 * @author Vaint
 * @E-mail vaintwyt@163.com
 * 
 */
public class EncryptUtils {
	/** RSA加密的公钥 ，与服务端的私钥对应*/
	private static final String publicKeyStr = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC0dLTXOCN7VMM4MbbxkVIwIRmEjzlKJSbd97uoWiwt3z/Q1u4DQNfTVdeLtDIEFeYUz1/mJPltMdlUDB8/YO2MfHnvipk4DC+C7mZ5DgP/5Qtglvl6alPTL2yhZNpJ5MCJQNvYk7l5A1lDwSwFKkFmBl2vHeGY76C/Y62ofeZYRwIDAQAB";

	private static char[] HEX_CHAR = { '0', '1', '2', '3', '4', '5', '6', '7',
			'8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };

	/**
	 * RSA加密
	 * 
	 * @param src
	 * @return
	 */
	public static String GetRsaEncrypt(String src) {
		if (src == null)
			return "";

		String enData = null;
		try {
			Cipher cipher = Cipher.getInstance("RSA",
					new BouncyCastleProvider());
			RSAPublicKey pubKey = GetPublicKey(publicKeyStr);
			cipher.init(Cipher.ENCRYPT_MODE, pubKey);
			byte[] output = cipher.doFinal(src.getBytes("UTF-8"));
			enData = ByteToString(output);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return enData;
	}

	/**
	 * MD5加密
	 * 
	 * @param src
	 * @return MD5加密后的数据
	 */
	public static String GetMD5(String src) {
		if (src == null)
			return "";

		String des = null;
		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			md.update(src.getBytes("UTF-8"));
			byte tmp[] = md.digest();
			char str[] = new char[16 * 2];
			int k = 0;
			for (int i = 0; i < 16; i++) {
				byte byte0 = tmp[i];
				str[k++] = HEX_CHAR[byte0 >>> 4 & 0xf];
				str[k++] = HEX_CHAR[byte0 & 0xf];
			}
			des = new String(str);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return des;
	}

	private static String ByteToString(byte[] data) {
		StringBuilder stringBuilder = new StringBuilder();
		for (int i = 0; i < data.length; i++) {
			// 取出字节的高四位 作为索引得到相应的十六进制标识符 注意无符号右移
			stringBuilder.append(HEX_CHAR[(data[i] & 0xf0) >>> 4]);
			// 取出字节的低四位 作为索引得到相应的十六进制标识符
			stringBuilder.append(HEX_CHAR[(data[i] & 0x0f)]);
		}
		return stringBuilder.toString();
	}

	/**
	 * 将String型私钥转换为RSAPublicKey
	 * 
	 * @param publicKeyStr
	 *            公钥数据字符串
	 */
	private static RSAPublicKey GetPublicKey(String publicKeyStr) {
		RSAPublicKey pubKey = null;
		try {
			BASE64Decoder base64Decoder = new BASE64Decoder();
			byte[] buffer = base64Decoder.decodeBuffer(publicKeyStr);
			KeyFactory keyFactory = KeyFactory.getInstance("RSA");
			X509EncodedKeySpec keySpec = new X509EncodedKeySpec(buffer);
			pubKey = (RSAPublicKey) keyFactory.generatePublic(keySpec);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return pubKey;
	}

	/**
	 * 数据压缩，zip格式
	 * @param src
	 * @return BASE64编码后的字符串
	 */
	public static String Compress(String src) {
		if (src == null || src.isEmpty()) {
			return src;
		}
		String des = "";
		try {
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			GZIPOutputStream gzip = new GZIPOutputStream(out);
			gzip.write(src.getBytes());
			gzip.close();
			des = out.toString("ISO-8859-1");
		} catch (IOException e) {
			e.printStackTrace();
		}
		return des;
	}
	
	/**
	 * 数据zip解压缩
	 * @param src
	 * @return
	 */
	public static String DeCompress(String src)
	{
		if (src == null || src.isEmpty()) {
            return src;
        }
        String des = "";
        try {
        	ByteArrayOutputStream out = new ByteArrayOutputStream();
            ByteArrayInputStream in = new ByteArrayInputStream(
                    src.getBytes("ISO-8859-1"));
            GZIPInputStream gunzip = new GZIPInputStream(in);
            byte[] buffer = new byte[512];
            int n;
            while ((n = gunzip.read(buffer)) >= 0) {
                out.write(buffer, 0, n);
            }
            des = out.toString();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return des;
	}
}
