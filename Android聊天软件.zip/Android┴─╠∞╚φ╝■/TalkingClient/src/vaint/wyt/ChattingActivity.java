package vaint.wyt;

import java.util.ArrayList;
import java.util.List;

import vaint.wyt.bean.ChatData;
import vaint.wyt.bean.ChatData.MSG;
import vaint.wyt.bean.ChatListModel;
import vaint.wyt.bean.ChattingModel;
import vaint.wyt.bean.User;
import vaint.wyt.constant.Constants;
import vaint.wyt.db.CacheUtils;
import vaint.wyt.db.DataUtils;
import vaint.wyt.manage.FriendInfoActivity;
import vaint.wyt.msg.MsgUtils;
import vaint.wyt.msg.ThreadUtils;
import vaint.wyt.view.ChattingAdapter;
import vaint.wyt.view.FacialEditLayout;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.ListView;

public class ChattingActivity extends ActionBarActivity{
	private static final String TAG = ChattingActivity.class.getSimpleName();
	
	private Context mContext;
	private ActionBar mActionBar;
	private ListView mListView;
	private ChattingAdapter mAdapter;
	private FacialEditLayout mFacialEditLayout;
	
	private Handler mMultiHandler;
	
	/**好友信息*/
	private User mFriend;
	/**好友ID*/
	private String mFriendId;
	/**接收消息的广播*/
	private BroadcastReceiver mMsgBroadcast;
	
	/**最后一条消息内容*/
	private String mLastMsg;
	/**最后一条消息的时间*/
	private String mLastTime;
	/**上一条消息显示的时间*/
	private long lastTime;
	
	/**新的聊天信息*/
	private List<ChattingModel> mNewChattingList = new ArrayList<ChattingModel>();
	/**全部聊天信息,新的消息在后面*/
	private List<ChattingModel> mChattingList;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_chatting);
		
		mContext = this;
		mActionBar = getSupportActionBar();
		mMultiHandler = ThreadUtils.GetMultiHandler(TAG);
		
		// 启动activity时不自动弹出软键盘
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
		findViews();
		setListener();
		
		Intent intent = getIntent();
		mFriend = (User) intent.getSerializableExtra(Constants.Flags.CHATTING_FRIEND);
		mFriendId = mFriend.getUserId();
		
		mActionBar.setTitle(mFriend.getName());
		
		//获取该好友的聊天记录
		mChattingList = DataUtils.GetChattingList(mFriendId);
		 
		mAdapter = new ChattingAdapter(mContext, mChattingList);
		mListView.setAdapter(mAdapter);
		
		//注册接收消息的广播
		IntentFilter intentFilter = new IntentFilter(); 
		mMsgBroadcast = new MsgBroadcastReceiver();
		//Action命名规则，以好友ID作为标识
		intentFilter.addAction(Constants.Actions.CHATTING_PREFIX + mFriendId);
		registerReceiver(mMsgBroadcast, intentFilter);
		
		//存储当前好友会话的广播名
		MsgUtils.SetCurrBroadCast(mFriendId);
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.menu_chatting, menu);
		return super.onCreateOptionsMenu(menu);
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if(item.getItemId() == R.id.chatting_menu_friendInfo)
		{
			Intent intent = new Intent(mContext, FriendInfoActivity.class);
			intent.putExtra(Constants.Flags.FRIEND_INFO, mFriend);
			startActivity(intent);
		}
		return false;
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		//如果有新的聊天消息，则需要更新聊天列表的信息
		if(mNewChattingList.size() > 0)
		{
			//保存聊天记录
			DataUtils.UpdateChattingList(mFriendId, mChattingList);
			
			//更新聊天列表
			ChatListModel model = new ChatListModel();
			model.setPhoto(mFriend.getPhoto());
			model.setTitle(mFriend.getName());
			model.setUnread(0);
			model.setFriendId(mFriendId);
			model.setContent(mLastMsg);
			model.setTime(mLastTime);
			
			DataUtils.UpdateChatList(mFriendId, model);
		}
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		
		if(mMsgBroadcast!=null)
		{
			//卸载广播
			unregisterReceiver(mMsgBroadcast);
		}
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if(keyCode == KeyEvent.KEYCODE_BACK)
		{
			if(mFacialEditLayout.isFacialShow())
			{
				//隐藏表情框
				mFacialEditLayout.hideFacialView();
				return true;
			}
		}
		return super.onKeyDown(keyCode, event);
	}

	private void setListener()
	{
		//点击聊天消息的界面，隐藏键盘或表情框
		mListView.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				hideKeyBoard();
				mFacialEditLayout.hideFacialView();
				return false;
			}
		});
		
		//设置发送按钮点击监听
		mFacialEditLayout.setOnSendBtnClickListener(new FacialEditLayout.OnSendBtnClickListener() {
			@Override
			public void onBtnClicked(String input) {
				//清空编辑框
				mFacialEditLayout.clearMsgEdit();
				
				ChattingModel model = new ChattingModel();
				final ChatData.MSG Msg = new ChatData.MSG();

				long currTime = System.currentTimeMillis();
				String time = MsgUtils.GetFormatTime();
				model.setTime(time);
				model.setShowTime((currTime - lastTime) > 60000);// 间隔超过60秒，则显示消息的时间
				model.setPhoto(mFriend.getPhoto());
				model.setSend(true);
				model.setMsg(input);

				Msg.setTime(time);
				Msg.setFromId(CacheUtils.GetUserId());
				Msg.setToId(mFriendId);
				Msg.setMsg(input);

				lastTime = currTime;
				mLastMsg = input;
				mLastTime = time;

				// 缓存新的聊天记录
				mNewChattingList.add(model);
				mChattingList.add(model);
				
//				 mAdapter.updateListView(mChattingList);
				//由于聊天界面中，使用左右两个布局。如果只是通过updateListView更新布局数据，会导致聊天消息错位
				mAdapter = new ChattingAdapter(mContext, mChattingList);
				mListView.setAdapter(mAdapter);

				// 异步发送消息给好友
				mMultiHandler.post(new Runnable() {
					public void run() {
						MsgUtils.SendMsg(Msg);
					}
				});
			}
		});
		
	}

	private void findViews()
	{
		mListView = (ListView) findViewById(R.id.chatting_listView);
		mFacialEditLayout = (FacialEditLayout) findViewById(R.id.chatting_facialLayout);
	}
	
	/** 隐藏软键盘 */
	private void hideKeyBoard() {
		((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE))
				.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),
						InputMethodManager.HIDE_NOT_ALWAYS);
	}

	/**显示当前好友的消息的广播*/
	class MsgBroadcastReceiver extends BroadcastReceiver
	{
		@Override
		public void onReceive(Context ctx, Intent intent) {
			MSG msg = (MSG) intent.getSerializableExtra(Constants.Flags.MSG);
			
			ChattingModel model = new ChattingModel();
			User friend = CacheUtils.GetFriend(msg.getFromId());
			model.setPhoto(friend.getPhoto());
			model.setMsg(msg.getMsg());
			model.setSend(false);
			model.setTime(msg.getTime());
			long currTime = System.currentTimeMillis();
			model.setShowTime((currTime - lastTime) > 60000);//间隔超过60秒，则显示消息的时间
			lastTime = currTime;
			
			//记录聊天记录
			mNewChattingList.add(model);
			mChattingList.add(model);
			//显示消息
			
//			mAdapter.updateListView(mChattingList);
			mAdapter = new ChattingAdapter(mContext, mChattingList);
			mListView.setAdapter(mAdapter);
		}
	}
}
