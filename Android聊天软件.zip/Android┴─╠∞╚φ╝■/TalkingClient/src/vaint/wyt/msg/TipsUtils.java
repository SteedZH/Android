package vaint.wyt.msg;

import java.util.List;

import vaint.wyt.MainActivity;
import vaint.wyt.R;
import vaint.wyt.constant.Constants;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningTaskInfo;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Vibrator;
import android.preference.PreferenceManager;

public class TipsUtils {
	private static SharedPreferences mPreference;
	private static Context mContext;
	private static Vibrator mVibrator;
	private static SoundPool mSoundPool;
	private static int mSoundId;
	private static long mLastTime;
	private static boolean mIsVoice;
	private static boolean mIsVibrate;
	
	private static NotificationManager mNotificationManager;
	private static Notification mNotification;
	
	/**
	 * 初始化震动和声音提示,以及通知<BR/>
	 * 对应设置更改后，需要再次调用此方法
	 * @param ctx
	 */
	public static void InitTips(Context ctx)
	{
		mPreference = (SharedPreferences) PreferenceManager.getDefaultSharedPreferences(ctx);
		mContext = ctx;
		mIsVibrate = mPreference.getBoolean("vibrateTips", false);
		mIsVoice = mPreference.getBoolean("voiceTips", false);
		if(mIsVibrate && mVibrator == null)
		{
			mVibrator = (Vibrator) mContext.getSystemService(Context.VIBRATOR_SERVICE);
		}
		if(mIsVoice && mSoundPool == null)
		{
			mSoundPool = new SoundPool(2, AudioManager.STREAM_MUSIC, 0);
			mSoundId = mSoundPool.load(ctx, R.raw.tips, 1);
		}
		
		mNotificationManager = (NotificationManager) ctx
				.getSystemService(Context.NOTIFICATION_SERVICE);
		// 创建一个Notification
		mNotification = new Notification();
		// 设置显示在手机最上边的状态栏的图标
		mNotification.icon = R.drawable.ic_launcher;
		mNotification.when = System.currentTimeMillis();
		// 当当前的notification被放到状态栏上的时候，提示内容
		mNotification.tickerText = ctx.getText(R.string.txt_notify_msg);
		//LED灯提示
		mNotification.defaults |= Notification.DEFAULT_LIGHTS;
		//点击后自动消失
		mNotification.flags |= Notification.FLAG_AUTO_CANCEL;

		Intent intent = new Intent(ctx, MainActivity.class);
		PendingIntent pendingIntent = PendingIntent.getActivity(ctx, 0,
				intent, PendingIntent.FLAG_UPDATE_CURRENT);
		// 点击状态栏的图标出现的提示信息设置
		mNotification.setLatestEventInfo(ctx, ctx.getText(R.string.txt_notify_msg), "",
				pendingIntent);
	}
	
	/**
	 * 接收消息时，根据用户设置来做出提示<BR/>调用此方法前必须使用InitTips进行初始化
	 * @param time 通过System.currentTimeMillis()获得
	 */
	public static void ShowTips(long time)
	{
		//消息间隔5秒以上，出现震动和提示音
		if((time-mLastTime) > 5000)
		{
			if(mIsVibrate)
			{
				//震动提示
				long [] pattern = {100,100,200,100};   // 停止 开启 停止 开启   
				mVibrator.vibrate(pattern,-1);           //重复两次上面的pattern 如果只想震动一次，index设为-1
			}
			if(mIsVoice)
			{
				//循环播放两次
				mSoundPool.play(mSoundId, 1, 1, 1, 1, 1);
			}
		}
		mLastTime = time;
	}
	
	/**消息通知提示*/
	public static void MsgNotificaction()
	{
		//声音和震动提示
		ShowTips(System.currentTimeMillis());
		
		//只有当程序在后台运行时，才显示通知
		if(isBackgroundRunning())
		{
			//设置相同的ID，覆盖提示
			mNotificationManager.notify(Constants.NOTIFY_ID, mNotification);
		}
	}
	
	/**清理通知*/
	public static void ClearNotification()
	{
		mNotificationManager.cancel(Constants.NOTIFY_ID);
	}
	
	/**判断当前程序是否后台运行。此方法需要添加权限android.permission.GET_TASKS*/
	private static boolean isBackgroundRunning()
	{
		ActivityManager am = (ActivityManager) mContext.getSystemService(Context.ACTIVITY_SERVICE);
        List<RunningTaskInfo> tasks = am.getRunningTasks(1);
        if (!tasks.isEmpty()) {
            ComponentName topActivity = tasks.get(0).topActivity;
            if (!topActivity.getPackageName().equals(mContext.getPackageName())) {
                return true;
            }
        }
        return false;
	}
}
