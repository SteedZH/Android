package vaint.wyt.msg;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


import android.content.Context;
import android.content.Intent;
import android.util.Log;

import vaint.wyt.ChatConnThread;
import vaint.wyt.R;
import vaint.wyt.bean.ChatData;
import vaint.wyt.bean.ChatData.MSG;
import vaint.wyt.bean.ChatData.Type;
import vaint.wyt.bean.ChatListModel;
import vaint.wyt.bean.ChattingModel;
import vaint.wyt.bean.FriendList;
import vaint.wyt.bean.NewFriendsModel;
import vaint.wyt.bean.User;
import vaint.wyt.constant.Constants;
import vaint.wyt.db.CacheUtils;
import vaint.wyt.db.DataUtils;

/**
 * 消息发送工具类
 * @author Vaint
 *@E-mail vaintwyt@163.com
 *
 */
public class MsgUtils {
	private static ChatConnThread connThread;
	private static String currBroadcast;
	
	/**设置连接线程*/
	public static void SetConnThread(ChatConnThread thread)
	{
		connThread = thread;
	}
	
	/**获得离线消息*/
	public static void GetOfflineMsg()
	{
		ChatData.MSG msg = new ChatData.MSG();
		msg.setType(ChatData.Type.OFFLINE_MSG);
		msg.setFromId(CacheUtils.GetUserId());
		
		connThread.sendMsg(msg);
	}
	
	/**发送消息给好友,或服务端*/
	public static void SendMsg(ChatData.MSG msg)
	{
		connThread.sendMsg(msg);
	}
	
	/**关闭连接线程*/
	public static void CloseConn()
	{
		//只有当连接没有断开的情况下，才通知服务端
		if(connThread.isOnLine())
		{
			Log.d("vaint", "通知服务器，关闭连接");
			MSG msg = new MSG();
			msg.setFromId(CacheUtils.GetUserId());
			msg.setType(Type.LOGOUT);
			SendMsg(msg);
		}
		
		connThread.closeConn();
	}
	
	
	/*****************************消息显示********************************/
	/*
	 * 显示接收的消息
	 * 有三种情况
	 * 1.处于该好友的会话界面：直接显示消息
	 * 2.处于聊天列表界面：更新聊天列表
	 * 3.其他界面：存储消息，回来聊天列表界面进行显示
	 * 
	 */
	/**显示聊天消息*/
	public static void ShowChattingMsg(Context ctx, MSG msg)
	{
		//判断当前处于那种情况
		if(msg.getFromId().equals(currBroadcast))//情况1，该好友的会话界面
		{
			//发送广播
			Intent intent = new Intent(Constants.Actions.CHATTING_PREFIX + msg.getFromId());
			intent.putExtra(Constants.Flags.MSG, msg);
			ctx.sendBroadcast(intent);
			return;
		}
		
		String friendId = msg.getFromId();
		User friend = CacheUtils.GetFriend(friendId);
		{
			//聊天记录
			ChattingModel model = new ChattingModel();
			model.setPhoto(friend.getPhoto());
			model.setSend(false);
			model.setMsg(msg.getMsg());
			model.setTime(msg.getTime());
			model.setShowTime(true);//设置显示时间
			
			//添加一条聊天记录
			 DataUtils.AddChattingItem(friendId, model, true);
		}
		{
			//聊天列表
			ChatListModel model = new ChatListModel();
			model.setPhoto(friend.getPhoto());
			model.setTitle(friend.getName());
			model.setUnread(1);
			model.setFriendId(friendId);
			model.setContent(msg.getMsg());
			model.setTime(msg.getTime());
			
			//更新聊天列表
			DataUtils.UpdateChatList(friendId, model);
		}
		
		if(Constants.Actions.CHAT_LIST.equals(currBroadcast))//情况2，处于聊天列表界面
		{
			//发送广播
			Intent intent = new Intent(Constants.Actions.CHAT_LIST);
			ctx.sendBroadcast(intent);
		}
		//情况3，其他界面
	}
	
	/*
	 * 显示添加好友的消息
	 * 有三种情况
	 * 1.处于新的好友的界面：直接显示消息
	 * 2.处于好友列表界面：显示提示
	 * 3.其他界面：存储消息
	 * 
	 */
	/**显示好友请求消息*/
	public static void ShowAddFriendMsg(Context ctx, MSG msg)
	{
		NewFriendsModel model = new NewFriendsModel();
		model.setPhoto(msg.getPhoto());
		model.setName(msg.getName());
		model.setUserId(msg.getFromId());
		model.setVerifyMsg(msg.getMsg());
		model.setTime(msg.getTime());
		model.setAgreed(false);//好友请求，设置为未同意添加
		
		List<NewFriendsModel> list = CacheUtils.GetNewFriendsList();
		//判断原来是否有该好友的请求
		for(int i=0;i<list.size();i++)
		{
			NewFriendsModel m = list.get(i);
			if(m.getUserId().equals(msg.getFromId()))//如果存在
			{
				//判断是否已经同意其请求
				if(!m.isAgreed())//如果之前没有同意，才再次覆盖显示，否则不再更新显示
				{
					list.remove(i);
					break;
				}
			}
		}
		list.add(0, model);// 添加到首位

		//更新好友请求列表
		DataUtils.UpdateNewFriendsList(list);
		
		if(Constants.Actions.NEW_FRIEND_LIST.equals(currBroadcast))//情况1.处于新的好友的界面
		{
			//发送广播
			Intent intent = new Intent(Constants.Actions.NEW_FRIEND_LIST);
			intent.putExtra(Constants.Flags.NEW_FRIEND_LIST, model);
			ctx.sendBroadcast(intent);
		}
		else if(Constants.Actions.CONTACTS_LIST.equals(currBroadcast))//情况2.处于好友列表界面
		{
			// 发送广播
			Intent intent = new Intent(Constants.Actions.NEW_FRIEND_TIPS);
			ctx.sendBroadcast(intent);
		}
		//情况3.其他界面  
	}
	
	/**添加一个新的好友<BR/>并且产生一个空白的聊天会话*/
	public static void AddNewFriend(Context ctx, MSG msg)
	{
		//更新好友列表
		FriendList friendList = CacheUtils.GetFriendList();
		
		List<User> friends = friendList.getFriends();
		//判断该好友是否已经在通讯录中
		for(int i=0;i<friends.size();i++)
		{
			User user = friends.get(i);
			if(user.getUserId().equals(msg.getFromId()))//已经存在
			{
				return;
			}
		}
		
		User user = new User();
		user.setPhoto(msg.getPhoto());
		user.setName(msg.getName());
		user.setUserId(msg.getFromId());
		friends.add(user);

		friendList.setFriends(friends);
		//更新好友列表
		DataUtils.UpdateFriendList(friendList);
		
		//聊天列表
		ChatListModel model = new ChatListModel();
		model.setUnread(1);
		model.setFriendId(msg.getFromId());
		model.setPhoto(msg.getPhoto());
		model.setTitle(msg.getName());
		model.setTime(MsgUtils.GetFormatTime());
		model.setContent(ctx.getString(R.string.txt_say_hi));
		//更新聊天列表
		DataUtils.UpdateChatList(msg.getFromId(), model);
		
		if(Constants.Actions.CONTACTS_LIST.equals(currBroadcast))//处于好友列表界面
		{
			// 发送广播
			Intent intent = new Intent(Constants.Actions.CONTACTS_LIST);
			ctx.sendBroadcast(intent);
		}else if(Constants.Actions.CHAT_LIST.equals(currBroadcast))//处于聊天列表界面
		{
			// 发送广播
			Intent intent = new Intent(Constants.Actions.CHAT_LIST);
			ctx.sendBroadcast(intent);
		}
	}
	
	
	/**存储当前的Broadcast*/
	public static void SetCurrBroadCast(String broadcastName)
	{
		currBroadcast = broadcastName;
	}
	
	/**清除当前的Broadcast*/
	public static void ClearCurrBroadCast()
	{
		currBroadcast = null;
	}
	
	
	/**获得MM-dd HH:mm格式的当前时间*/
	public static String GetFormatTime()
	{
		long currTime = System.currentTimeMillis();
		SimpleDateFormat formatter = new SimpleDateFormat("MM-dd HH:mm");
		Date curDate = new Date(currTime);// 获取当前时间
		String time = formatter.format(curDate);
		return time;
	}
}
