package vaint.wyt.msg;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import vaint.wyt.R;
import vaint.wyt.bean.SmileyFacial;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.ImageSpan;
import android.util.Log;

/**
 * 表情工具
 * @author Vaint
 *@E-mail vaintwyt@163.com
 *
 */
public class FacialUtils {
	/** 每一页表情的个数 */  
    private int pageSize = 20;  
  
    private static FacialUtils mFacialUtil;  
  
    /** 保存于内存中的表情HashMap */  
    private HashMap<String, String> smileyMap = new HashMap<String, String>();  
  
    /** 保存于内存中的表情集合 */  
    private List<SmileyFacial> smileys = new ArrayList<SmileyFacial>();  
  
    /** 表情分页的结果集合 */  
    private List<List<SmileyFacial>> smileyLists = new ArrayList<List<SmileyFacial>>();  
  
    private FacialUtils() {  
    }  
  
    public static FacialUtils getInstace() {  
        if (mFacialUtil == null) {  
        	mFacialUtil = new FacialUtils();  
        }  
        return mFacialUtil;  
    }  
  
    /** 
     * 初始化表情和对应字符串 
     */  
    public void InitFacialData(Context context) { 
    	String[] data = context.getResources().getStringArray(R.array.smiley_values);
        if (data == null) {  
            return;  
        }  
        SmileyFacial smileyEentry;  
        try {  
            for (int i=0;i<data.length;i++) {  
            	String pngName = "smiley_"+i;
                smileyMap.put(data[i], pngName);  
                int resID = context.getResources().getIdentifier(pngName,  
                        "drawable", context.getPackageName());  
  
                if (resID != 0) {  
                	smileyEentry = new SmileyFacial();  
                	smileyEentry.setId(resID);  
                	smileyEentry.setCharacter(data[i]);  
                	smileyEentry.setName(pngName);  
                    smileys.add(smileyEentry);  
                }  
            }  
            int pageCount = (int) Math.ceil(smileys.size() / pageSize + 0.1);  
  
            for (int i = 0; i < pageCount; i++) {  
                smileyLists.add(getData(i));  
            }  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
    }  
    
    /**
     * 获得表情集合
     */
    public List<List<SmileyFacial>> getFacialData()
    {
    	return smileyLists;
    }
    
    /** 
     * 将字符串进行正则匹配，用于显示表情 
     * @param str 含有[**]表情标识的字串
     * @return 可通过TextView或EditText的setText方法直接显示表情的SpannableString
     */  
    public SpannableString showFacial(Context context, String str) {  
        SpannableString spannableString = new SpannableString(str);  
        // 正则表达式比配字符串里是否含有表情，如： 我好[开心]啊  
        String regex = "\\[[^\\]]+\\]";  
        // 通过传入的正则表达式来生成一个pattern  
        Pattern sinaPatten = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);  
        try {  
            dealExpression(context, spannableString, sinaPatten, 0);  
        } catch (Exception e) {  
            Log.e("dealExpression", e.getMessage());  
        }  
        return spannableString;  
    }  
  
    /** 
     * 添加表情
     */  
    public SpannableString addFacial(Context context, int imgId,  
            String str) {  
        if (TextUtils.isEmpty(str)) {  
            return null;  
        }
        Drawable drawable = context.getResources().getDrawable(imgId);
        drawable.setBounds(0, 0, 30, 30);
        ImageSpan imageSpan = new ImageSpan(drawable);  
        SpannableString spannable = new SpannableString(str);  
        spannable.setSpan(imageSpan, 0, str.length(),  
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);  
        return spannable;  
    }  
  
    /** 
     * 对spanableString进行正则判断，如果符合要求，则以表情图片代替 
     */  
    private void dealExpression(Context context,  
            SpannableString spannableString, Pattern patten, int start)  
            throws Exception {  
        Matcher matcher = patten.matcher(spannableString);  
        while (matcher.find()) {  
            String key = matcher.group();  
            // 返回第一个字符的索引的文本匹配整个正则表达式,ture 则继续递归  
            if (matcher.start() < start) {  
                continue;  
            }  
            String value = smileyMap.get(key);  
            if (TextUtils.isEmpty(value)) {  
                continue;  
            }  
            int resId = context.getResources().getIdentifier(value, "drawable",  
                    context.getPackageName());  
            if (resId != 0) {
            	Drawable drawable = context.getResources().getDrawable(resId);
                drawable.setBounds(0, 0, 30, 30);
                // 通过图片资源id来得到drawable，用一个ImageSpan来包装  
                ImageSpan imageSpan = new ImageSpan(drawable);
                // 计算该图片名字的长度，也就是要替换的字符串的长度  
                int end = matcher.start() + key.length();  
                // 将该图片替换字符串中规定的位置中  
                spannableString.setSpan(imageSpan, matcher.start(), end,  
                        Spannable.SPAN_INCLUSIVE_EXCLUSIVE);
                if (end < spannableString.length()) {  
                    // 如果整个字符串还未验证完，则继续。。  
                    dealExpression(context, spannableString, patten, end);  
                }  
                break;  
            }  
        }  
    }  
  
    
  
    /** 
     * 获取分页数据 
     */  
    private List<SmileyFacial> getData(int page) {  
        int startIndex = page * pageSize;  
        int endIndex = startIndex + pageSize;  
  
        if (endIndex > smileys.size()) {  
            endIndex = smileys.size();  
        }  
        // 不这么写，会在viewpager加载中报集合操作异常，我也不知道为什么  
        List<SmileyFacial> list = new ArrayList<SmileyFacial>();  
        list.addAll(smileys.subList(startIndex, endIndex));  
        if (list.size() < pageSize) {  
            for (int i = list.size(); i < pageSize; i++) {  
            	SmileyFacial object = new SmileyFacial();  
                list.add(object);  
            }  
        }  
        if (list.size() == pageSize) {  
            SmileyFacial object = new SmileyFacial();  
            object.setId(R.drawable.facial_del_selector);  
            list.add(object);  
        }  
        return list;  
    }  
}
