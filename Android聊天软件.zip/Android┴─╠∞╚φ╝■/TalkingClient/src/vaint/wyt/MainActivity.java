package vaint.wyt;

import org.json.JSONObject;

import vaint.wyt.bean.User;
import vaint.wyt.constant.Constants;
import vaint.wyt.db.CacheUtils;
import vaint.wyt.db.DataUtils;
import vaint.wyt.encrypt.EncryptUtils;
import vaint.wyt.http.HttpCallBackListener;
import vaint.wyt.http.HttpUtils;
import vaint.wyt.login.LoginActivity;
import vaint.wyt.manage.AddFriendActivity;
import vaint.wyt.manage.SettingActivity;
import vaint.wyt.manage.UserInfoActivity;
import vaint.wyt.msg.FacialUtils;
import vaint.wyt.msg.MsgUtils;
import vaint.wyt.msg.ThreadUtils;
import vaint.wyt.msg.TipsUtils;
import vaint.wyt.view.ViewUtils;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBar.Tab;
import android.support.v7.app.ActionBar.TabListener;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.PopupMenu.OnMenuItemClickListener;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;

public class MainActivity extends ActionBarActivity implements OnMenuItemClickListener, HttpCallBackListener{
	private static final String TAG = MainActivity.class.getSimpleName();
	
	private Context mContext;
	private PopupMenu mAddMenu;
	private PopupMenu mManageMenu;
	private ActionBar mActionBar;
	
	private ChatFragment mChatFragment;  
	private ContactsFragment mContactsFragment;
	
	/**多线程Handler*/
	private Handler mChatConnHandler;
	private Handler mMultiHandler;
	
	private ChatConnThread mConnThread;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        mContext = this;
        mChatFragment = new ChatFragment(); 
        mContactsFragment = new ContactsFragment();
        setActionBar();
        
        //处理耗时操作的Handler
        mMultiHandler = ThreadUtils.GetMultiHandler(TAG);
        //处理聊天业务的Handler
        mChatConnHandler = ThreadUtils.GetMultiHandler(TAG+"_ChatConn");
        
        //初次登陆，获取好友列表
        mMultiHandler.post(mGetContactsListThread);
        
        //开启消息处理线程
        mConnThread = new ChatConnThread(mContext);
        mChatConnHandler.post(mConnThread);
        
        //初始化数据库工具类
        DataUtils.Init(mContext, CacheUtils.GetUserId());
        
        //初始化消息发送工具类
        MsgUtils.SetConnThread(mConnThread);
        
        //初始化表情工具类
        FacialUtils.getInstace().InitFacialData(mContext);
    }
    
    @Override
	protected void onResume() {
		super.onResume();
		//显示用户头像和昵称
		User user = CacheUtils.GetUserCache();
        if(user != null)
        {
        	Drawable drawable = ViewUtils.StringToDrawable(user.getPhoto());
			if(drawable==null)
			{
				//使用默认头像
				drawable = getResources().getDrawable(R.drawable.photo_default);
			}
        	mActionBar.setIcon(drawable);
        	mActionBar.setTitle(user.getName());
        }
        
        //根据用户设置，初始化震动和声音提示
        TipsUtils.InitTips(mContext);
        
        //回到程序，清理通知
        TipsUtils.ClearNotification();
        
	}
    
	private void setActionBar()
    {
    	mActionBar = getSupportActionBar();
        mActionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);
//      mActionBar.setDisplayShowTitleEnabled(false);//隐藏ActionBar的title
        
        TabListener listener = new MyTabListener();
        mActionBar.addTab(mActionBar.newTab().setIcon(R.drawable.main_tab_chat).setText(R.string.fragment_chat)  
                .setTabListener(listener));  
        mActionBar.addTab(mActionBar.newTab().setIcon(R.drawable.main_tab_contacts).setText(R.string.fragment_contacts)  
                .setTabListener(listener));
        
    }
	
	Thread mGetContactsListThread = new Thread(new Runnable(){
		@Override
		public void run() {
			JSONObject reqJson = new JSONObject();
			try {
				reqJson.put(Constants.GetFriendList.RequestParams.USER_ID, CacheUtils.GetUserId());
				Log.d(TAG, "获取好友列表请求 加密内容:"+reqJson.toString());
				// RSA 加密
				String data = EncryptUtils.GetRsaEncrypt(reqJson.toString());
				HttpUtils.sendRequest(Constants.ID.GET_FRIEND_LIST, data,
						MainActivity.this);
			} catch (Exception e) {
				e.printStackTrace();
				//失败则在10秒后再次获取好友列表
				mMultiHandler.postDelayed(this, 10000);
			}
		}
	});
	
    
    /**添加ActionBar的Menu*/
    @Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.menu_main, menu);
		return super.onCreateOptionsMenu(menu);
	}
    /**添加Menu的下拉子菜单*/
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.action_add:
			if(mAddMenu == null)
			{
		    	mAddMenu = new PopupMenu(mContext,
							findViewById(R.id.action_add));
		    	mAddMenu.inflate(R.menu.main_item_add);
		    	mAddMenu.setOnMenuItemClickListener(this);
			}
			mAddMenu.show();
			return true;
		case R.id.action_manage:
			if(mManageMenu == null)
			{
				mManageMenu = new PopupMenu(mContext,
		    			findViewById(R.id.action_manage));
		    	mManageMenu.inflate(R.menu.main_item_manage);
		    	mManageMenu.setOnMenuItemClickListener(this);
			}
			mManageMenu.show();
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}
	/**监听子菜单的点击事件*/
	@Override
	public boolean onMenuItemClick(MenuItem menuItem) {
		Intent intent = new Intent();
		switch (menuItem.getItemId()) {
		case R.id.menu_addFriend:
		{
			intent.setClass(mContext, AddFriendActivity.class);
			startActivity(intent);
		}
			break;
		case R.id.menu_multiChat:
			//TODO 未实现群聊功能
			break;
		case R.id.menu_userInfo:
		{
			intent.setClass(mContext, UserInfoActivity.class);
			startActivity(intent);
		}
			break;
		case R.id.menu_setting:
			intent.setClass(mContext, SettingActivity.class);
			startActivity(intent);
			break;
		case R.id.menu_exit:
			new AlertDialog.Builder(mContext)
			.setMessage(R.string.dialog_msg_exit)
			.setPositiveButton(R.string.btn_ok, new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface arg0, int arg1) {
					ExitApp(true);
				}
			})
			.setNegativeButton(R.string.btn_cancel, null).show();
			break;
		case R.id.menu_logout:
			new AlertDialog.Builder(mContext)
			.setMessage(R.string.dialog_msg_logout)
			.setPositiveButton(R.string.btn_ok, new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface arg0, int arg1) {
					//跳转到登录界面
					Intent intent = new Intent(mContext, LoginActivity.class);
					//传递不要自动登录的标识
					intent.putExtra(Constants.Flags.AUTO_LOGIN, false);
					ExitApp(false);
					startActivity(intent);
				}
			})
			.setNegativeButton(R.string.btn_cancel, null).show();
			break;
		}
		return false;
	}
	
	/**退出程序
	 * @param force true:强制退出整个程序  false:只是退出主界面
	 */
	public void ExitApp(boolean force)
	{
		//关闭消息连接
    	MsgUtils.CloseConn();
    	//停止获取好友列表的线程
    	mMultiHandler.removeCallbacks(mGetContactsListThread);
    	
    	//关闭数据库
    	DataUtils.Close();
    	
    	if(force)
    	{
    		System.exit(0);
    	}else
    	{
    		((Activity) mContext).finish();
    	}
	}
	
	/**监听返回键，将程序后台运行*/
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if(keyCode == KeyEvent.KEYCODE_BACK)
		{
			//将Activity放置在后台运行，不销毁
			moveTaskToBack(false);//false 只对根Activity有效。true 对任何Activity都适用
	        return true;
		}
		return super.onKeyDown(keyCode, event);
	}
	
	
	/**TabListener实现类*/
	class MyTabListener implements TabListener{
		public void onTabSelected(Tab tab, FragmentTransaction arg1) {
			
			switch (tab.getPosition()) {  
			case 0://聊天界面
				getSupportFragmentManager().beginTransaction()  
				.replace(R.id.main_container, mChatFragment).commit();  
				break;  
			case 1://通讯录界面
				getSupportFragmentManager().beginTransaction()  
				.replace(R.id.main_container, mContactsFragment).commit();  
				break;  
			}  
		}
		public void onTabReselected(Tab arg0, FragmentTransaction arg1) {
		}
		public void onTabUnselected(Tab arg0, FragmentTransaction arg1) {
		}
	}

	/**网络连接的回调函数*/
	@Override
	public void httpCallBack(int id, JSONObject resp) {
		if (id == Constants.ID.GET_FRIEND_LIST) {
			Log.d(TAG, "获取好友列表的回调函数");
			String resCode = resp.optString(Constants.ResponseParams.RES_CODE);
			if ("0".equals(resCode)) {
				Log.d(TAG, "获取好友列表成功");
				
				//更新好友列表数据
				DataUtils.UpdateFriendList(resp);
				
				//根据好友列表更新聊天会话的好友头像和昵称
				DataUtils.UpdateChatListInfo(CacheUtils.GetFriendList());
				
				//获取离线消息
				MsgUtils.GetOfflineMsg();
				
				//之后每隔一个小时获取好友列表,以便更新好友的昵称和头像的修改
				mMultiHandler.postDelayed(mGetContactsListThread, 60*60*1000);
			}else
			{
				//失败则在10秒后再次获取好友列表
				mMultiHandler.postDelayed(mGetContactsListThread, 10000);
			}
		}
	}
}

