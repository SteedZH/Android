package vaint.wyt.login;

import java.net.SocketTimeoutException;

import org.apache.http.conn.ConnectTimeoutException;
import org.json.JSONObject;

import vaint.wyt.MainActivity;
import vaint.wyt.R;
import vaint.wyt.bean.User;
import vaint.wyt.constant.Constants;
import vaint.wyt.constant.HandlerID;
import vaint.wyt.db.CacheUtils;
import vaint.wyt.encrypt.EncryptUtils;
import vaint.wyt.http.HttpCallBackListener;
import vaint.wyt.http.HttpUtils;
import vaint.wyt.register.RegisterActivity;
import vaint.wyt.view.ViewUtils;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends Activity implements HttpCallBackListener {
	private static final String TAG = LoginActivity.class.getSimpleName();
	
	//preference的key
	private static final String NAME_PREFERENCE = "vaint.wyt.login.sharedpreference";
	private static final String KEY_USER_ID = "vaint.wyt.login.user_id";
	private static final String KEY_PASSWORD = "vaint.wyt.login.password";
	private static final String KEY_REMEMBER_PSD = "vaint.wyt.login.remember_psd";
	/** 根据用户密码的长度，模拟出一个同等长度的字串 */
	private static final String KEY_SIMULATE_PSD = "vaint.wyt.login.simulate_psd";
	private static final String KEY_AUTO_LOGIN = "vaint.wyt.login.auto_login";

	private Context mContext;
	private Button mLoginBtn;
	private Button mRegisterBtn;
	private EditText mUserIdEdit;
	private EditText mPsdEdit;
	private CheckBox mRememberPsdCheckBox;
	private CheckBox mAutoLoginCheckBox;

	private SharedPreferences mSharedPreference;
	private boolean mIsRememberPsd;
	private boolean mIsPsdChanged;
	private boolean mIsAutoLogin;
	private String mPsdMd5;

	Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case HandlerID.SHOW_PRO_DIALOG:
				ViewUtils.ShowProgressDialog(mContext,
						(String)msg.obj);
				break;
			case HandlerID.HIDE_PRO_DIALOG:
				ViewUtils.HideProgressDialog();
				break;
			case HandlerID.CONNECT_TIMEOUT_DIALOG:
				ViewUtils.ShowConnectTimeoutDialog(mContext);
				break;
			case HandlerID.SYSTEM_BUSY_DIALOG:
				ViewUtils.ShowSystemBusyDialog(mContext);
				break;
			case HandlerID.SHOW_ERROR_DIALOG:
				ViewUtils.ShowErrorDialog(mContext, (String)msg.obj);
				break;
			}
		}
	};

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mSharedPreference = getSharedPreferences(NAME_PREFERENCE,
				Context.MODE_PRIVATE);
		String userId = mSharedPreference.getString(KEY_USER_ID, "");
		mPsdMd5 = mSharedPreference.getString(KEY_PASSWORD, "");
		mIsRememberPsd = mSharedPreference.getBoolean(KEY_REMEMBER_PSD, false);
		mIsAutoLogin = mSharedPreference.getBoolean(KEY_AUTO_LOGIN, false);
		Log.d(TAG, "userId="+userId);
		Log.d(TAG, "mPsdMd5="+mPsdMd5);
		Log.d(TAG, "mIsRememberPsd="+mIsRememberPsd);
		Log.d(TAG, "mIsAutoLogin="+mIsAutoLogin);
		
		//如果由主界面注销跳转到此，则有参数
		boolean auto = getIntent().getBooleanExtra(Constants.Flags.AUTO_LOGIN, true);
		
		setContentView(R.layout.layout_login);
		mContext = this;
		findViews();
		
		mUserIdEdit.setText(userId);
		if (mIsRememberPsd) {
			String simulatePsd = mSharedPreference.getString(
					KEY_SIMULATE_PSD, "");
			mPsdEdit.setText(simulatePsd);
			mRememberPsdCheckBox.setChecked(true);
		}
		if(mIsAutoLogin)
		{
			mAutoLoginCheckBox.setChecked(true);
		}
		//监听要在上述控件数据设置的后面
		setListener();
		
		if (auto && mIsAutoLogin) {
			// 发起登录请求
			login(userId, mPsdMd5);
		} 

	}

	private void setListener() {
		mPsdEdit.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
			}
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
			}
			@Override
			public void afterTextChanged(Editable s) {
				mIsPsdChanged = true;
			}
		});

		mRememberPsdCheckBox
		.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView,
					boolean isChecked) {
				if (!isChecked)// 不需要记住密码
				{
					//将自动登录设置为不选状态
					mAutoLoginCheckBox.setChecked(false);
				}
			}
		});
		
		mAutoLoginCheckBox
				.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
					@Override
					public void onCheckedChanged(CompoundButton buttonView,
							boolean isChecked) {
						if (isChecked)// 自动登录
						{
							//选择自动登录，需要将记住密码自动选上
							mRememberPsdCheckBox.setChecked(true);
						}
					}
				});

		mLoginBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				final String userId = mUserIdEdit.getText().toString();
				String psd = mPsdEdit.getText().toString();

				if (TextUtils.isEmpty(userId) || TextUtils.isEmpty(psd)) {
					Toast.makeText(mContext, R.string.toast_id_psd_null,
							Toast.LENGTH_SHORT).show();
					return;
				}

				if (userId.length() != 11) {
					Toast.makeText(mContext, R.string.toast_id_len_wrong,
							Toast.LENGTH_SHORT).show();
					return;
				}

				hideKeyBoard();
				
				String psdTmp;
				//如果勾选了记住密码，以及用户没有修改密码框数据，则使用保存的Md5密码进行登录
				if(mIsRememberPsd && !mIsPsdChanged)
				{
					psdTmp = mPsdMd5;
				}else
				{
					psdTmp = EncryptUtils.GetMD5(psd);
				}
				final String psdMd5= psdTmp;
				Log.d(TAG, "MD5后的密码:" + psdMd5);

				// 根据用户的选项存储数据
				SharedPreferences.Editor editor = mSharedPreference.edit();
				editor.putString(KEY_USER_ID, userId);
				//记住密码
				if (mRememberPsdCheckBox.isChecked()) {
					editor.putString(KEY_PASSWORD, psdMd5);
					editor.putBoolean(KEY_REMEMBER_PSD, true);
					// 保存长度与用户密码一致的模拟字串，用于在密码框显示‘*’
					StringBuilder simulatePsd = new StringBuilder();
					for (int i = 0; i < psd.length(); i++) {
						simulatePsd.append("1");
					}
					editor.putString(KEY_SIMULATE_PSD, simulatePsd.toString());
				} else {
					editor.putString(KEY_PASSWORD, "");
					editor.putBoolean(KEY_REMEMBER_PSD, false);
				}
				
				//自动登录
				if (mAutoLoginCheckBox.isChecked()) {
					editor.putBoolean(KEY_AUTO_LOGIN, true);
				} else {
					editor.putBoolean(KEY_AUTO_LOGIN, false);
				}
				editor.commit();//必须commit，否则数据无法保存
				
				// 发起登录请求
				login(userId, psdMd5);
			}
		});

		mRegisterBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(mContext,
						RegisterActivity.class);
				startActivity(intent);
			}
		});
	}

	/**
	 * 发起登录请求
	 * 
	 * @param userId
	 *            用户手机号
	 * @param psdMd5
	 *            MD5加密后的密码数据
	 */
	private void login(final String userId, final String psdMd5) {
		new Thread(new Runnable() {
			@Override
			public void run() {
				// 显示进度对话框
				Message msg = new Message();
				msg.what = HandlerID.SHOW_PRO_DIALOG;
				msg.obj = "正在登录...";
				mHandler.sendMessage(msg);
				
				JSONObject reqJson = new JSONObject();
				try {
					reqJson.put(Constants.Login.RequestParams.USER_ID, userId);
					reqJson.put(Constants.Register.RequestParams.PASSWORD,
							psdMd5);

					Log.d(TAG, "登录请求，加密内容:" + reqJson.toString());
					// RSA 加密
					String data = EncryptUtils.GetRsaEncrypt(reqJson.toString());
					HttpUtils.sendRequest(Constants.ID.LOGIN, data,
							LoginActivity.this);
				} catch (ConnectTimeoutException e) {
					Log.e(TAG, "网络连接超时", e);
					// 提示用户
					mHandler.sendEmptyMessage(HandlerID.HIDE_PRO_DIALOG);
					mHandler.sendEmptyMessage(HandlerID.CONNECT_TIMEOUT_DIALOG);
				} catch (SocketTimeoutException e) {
					Log.e(TAG, "系统繁忙", e);
					// 提示用户
					mHandler.sendEmptyMessage(HandlerID.HIDE_PRO_DIALOG);
					mHandler.sendEmptyMessage(HandlerID.SYSTEM_BUSY_DIALOG);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}).start();
	}

	private void findViews() {
		mLoginBtn = (Button) findViewById(R.id.login_loginBtn);
		mRegisterBtn = (Button) findViewById(R.id.login_registerBtn);
		mUserIdEdit = (EditText) findViewById(R.id.login_userID);
		mPsdEdit = (EditText) findViewById(R.id.login_password);
		mRememberPsdCheckBox = (CheckBox) findViewById(R.id.login_rememberPsdCheckBox);
		mAutoLoginCheckBox = (CheckBox) findViewById(R.id.login_autoLoginCheckBox);
	}

	/** 隐藏软键盘 */
	private void hideKeyBoard() {
		((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE))
				.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),
						InputMethodManager.HIDE_NOT_ALWAYS);
	}

	@Override
	public void httpCallBack(int id, JSONObject resp) {

		if (id == Constants.ID.LOGIN) {
			Log.d(TAG, "请求登录的回调函数");

			String resCode = resp.optString(Constants.ResponseParams.RES_CODE);
			if ("0".equals(resCode)) {
				Log.d(TAG, "登录成功");

				//缓存用户信息
				User user = new User();
				user.setUserId(resp.optString(Constants.Login.ResponseParams.USER_ID));
				user.setName(resp.optString(Constants.Login.ResponseParams.NAME));
				user.setGender(resp.optString(Constants.Login.ResponseParams.GENDER));
				user.setPhoto(resp.optString(Constants.Login.ResponseParams.PHOTO));
				CacheUtils.SetUserCache(user);
				
				// 进入主界面
				Intent intent = new Intent(mContext, MainActivity.class);
				((Activity) mContext).finish();
				startActivity(intent);
				
				// 隐藏进度对话框
				mHandler.sendEmptyMessage(HandlerID.HIDE_PRO_DIALOG);
			} else {
				// 隐藏进度对话框
				mHandler.sendEmptyMessage(HandlerID.HIDE_PRO_DIALOG);
				String resMsg = resp
						.optString(Constants.ResponseParams.RES_MSG);
				Log.e(TAG, "登录失败 :" + resMsg);

				String err = Constants.Login.GetErrorInfo(resCode);
				if (err != null) {
					Message msg = new Message();
					msg.what = HandlerID.SHOW_ERROR_DIALOG;
					msg.obj = err;
					mHandler.sendMessage(msg);
				}
			}
		}

	}
}
