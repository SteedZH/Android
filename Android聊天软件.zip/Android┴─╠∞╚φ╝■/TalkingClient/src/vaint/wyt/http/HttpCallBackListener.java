package vaint.wyt.http;

import org.json.JSONObject;

/**
 * 网络连接的回调接口
 * @author Vaint
 *@E-mail vaintwyt@163.com
 *
 */
public interface HttpCallBackListener {
	void httpCallBack(int id, JSONObject resp);
}
