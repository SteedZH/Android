package vaint.wyt.http;

import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

import android.util.Log;

import vaint.wyt.constant.Constants;

public class HttpUtils {
	private static final String TAG = HttpUtils.class.getSimpleName();

	/**
	 * 发送请求
	 * 
	 * @param id
	 *            模块ID
	 * @param data
	 *            RSA加密后的数据
	 * @param listener
	 *            响应的回调函数
	 * @throws ConnectTimeoutException
	 * @throws SocketTimeoutException
	 * @throws Exception
	 */
	public static void sendRequest(int id, String data,
			HttpCallBackListener listener) throws ConnectTimeoutException,
			SocketTimeoutException, Exception {
		String url = null;
		//需要上传photo的接口，则将photo作为一个参数进行传递
		String photo = null;
		boolean isNeedPhoto = false;
		switch (id) {
		case Constants.ID.GET_CODE:
			url = Constants.Register.GET_VERIFY_CODE_URL;
			break;
		case Constants.ID.CHECK_CODE:
			url = Constants.Register.CHECK_VERIFY_CODE_URL;
			break;
		case Constants.ID.REGISTER:
			url = Constants.Register.REGISTER_URL;
			break;
		case Constants.ID.LOGIN:
			url = Constants.Login.LOGIN_URL;
			break;
		case Constants.ID.MODIFY_USERINFO:
			url = Constants.UserInfo.MODIFY_USERINFO_URL;
			isNeedPhoto = true;
			String[] strArr = data.split("&");
			if(strArr.length == 2)//有photo的数据
			{
				photo = strArr[1];
			}
			data = strArr[0];
			Log.d(TAG, "photo="+photo);
			break;
		case Constants.ID.MODIFY_PSD:
			url = Constants.UserInfo.MODIFY_PSD_URL;
			break;
		case Constants.ID.GET_FRIEND_LIST:
			url = Constants.GetFriendList.GET_FRIEND_LIST_URL;
			break;
		case Constants.ID.SEARCH_USER:
			url = Constants.AddFriend.SEARCH_USER_URL;
			break;
		case Constants.ID.REMOVE_FRIEND:
			url = Constants.RemoveFriend.REMOVE_FRIEND_URL;
			break;
		default:
			Log.e(TAG, "业务ID不存在");
			return;
		}
		Log.d(TAG, "url = " + url);

		// HttpPost连接对象
		HttpPost httpPost = new HttpPost(url);
		//使用UTF-8编码
		httpPost.setHeader("Content-Type", "application/x-www-form-urlencoded; charset=utf-8");
		// 使用NameValuePair来保存要传递的Post参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		// 添加要传递的参数
		params.add(new BasicNameValuePair(Constants.RequestParams.DATA, data));
		if(isNeedPhoto)
		{
			params.add(new BasicNameValuePair(Constants.RequestParams.PHOTO, photo));
		}
		
		// 设置字符集
		HttpEntity httpEntity = new UrlEncodedFormEntity(params, HTTP.UTF_8);
		httpPost.setEntity(httpEntity);
		// 使用自定义的HttpClient
		HttpClient httpClient = CustomerHttpClient.getHttpClient();
		// 取得HttpResponse
		HttpResponse httpResponse = httpClient.execute(httpPost);
		// HttpStatus.SC_OK表示连接成功
		if (httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
			Log.d(TAG, "连接成功");
			// 取得返回的字符串
			String respStr = EntityUtils.toString(httpResponse.getEntity());
			JSONObject respJson = new JSONObject(respStr);
			//回调
			listener.httpCallBack(id, respJson);
		} else {
			Log.e(TAG, "连接失败");
		}
	}
}
