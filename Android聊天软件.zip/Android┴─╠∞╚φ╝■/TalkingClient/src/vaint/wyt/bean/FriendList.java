package vaint.wyt.bean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
/**
 * 好友列表类<BR/>
 * 用于存储，获取好友
 * @author Vaint
 *@E-mail vaintwyt@163.com
 *
 */
public class FriendList{
//	private int friendNum;
	private List<User> friends = new ArrayList<User>();
	private Map<String, User> friendsMap = new HashMap<String, User>();
//	public int getFriendNum() {
//		return friendNum;
//	}
//	public void setFriendNum(int friendNum) {
//		this.friendNum = friendNum;
//	}
	public List<User> getFriends() {
		return friends;
	}
	public Map<String, User> getFriendsMap() {
		
		 for(int i=0;i<friends.size();i++)
		 {
			 User user = friends.get(i);
			 friendsMap.put(user.getUserId(), user);
		 }
		 return friendsMap;
	}
	public void setFriends(List<User> friends) {
		this.friends = friends;
	}
}
