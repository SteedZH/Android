package vaint.wyt.bean;

import java.io.Serializable;


public class User implements Serializable{
	private static final long serialVersionUID = 3200153623822190057L;
	private String userId;
	private String name;
	private String gender;
	private String photo;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
}
