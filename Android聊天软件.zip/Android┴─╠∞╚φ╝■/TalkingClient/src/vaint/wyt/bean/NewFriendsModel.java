package vaint.wyt.bean;

import java.io.Serializable;

import vaint.wyt.view.ViewUtils;
import android.graphics.drawable.Drawable;
public class NewFriendsModel implements Serializable{
	private static final long serialVersionUID = -3515880018036316040L;
	private String userId;
	private String name;
	private String gender;
	private String time;
	private Drawable photo;
	private String verifyMsg;
	private boolean isAgreed;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public Drawable getPhoto() {
		return photo;
	}
	public String getPhotoString() {
		return ViewUtils.DrawableToString(photo);
	}
	public void setPhoto(Drawable photo) {
		this.photo = photo;
	}
	public void setPhoto(String photo) {
		this.photo = ViewUtils.StringToDrawable(photo);
	}
	public String getVerifyMsg() {
		return verifyMsg;
	}
	public void setVerifyMsg(String verifyMsg) {
		this.verifyMsg = verifyMsg;
	}
	public boolean isAgreed() {
		return isAgreed;
	}
	public void setAgreed(boolean isAgreed) {
		this.isAgreed = isAgreed;
	}
	//兼容SQLite没有boolean型 0:false,1:true
	public void setAgreed(int isAgreed) {
		if(isAgreed==0)
		{
			this.isAgreed = false;
		}else
		{
			this.isAgreed = true;
		}
	}
}
