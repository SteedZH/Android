package vaint.wyt.bean;

/**
 * Smiley表情类
 * 
 * @author Vaint
 * @E-mail vaintwyt@163.com
 * 
 */
public class SmileyFacial {
	private int id;						//资源ID
	private String name;			//图片名
	private String character;	//对应字符串：[哈哈]

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCharacter() {
		return character;
	}

	public void setCharacter(String character) {
		this.character = character;
	}
}
