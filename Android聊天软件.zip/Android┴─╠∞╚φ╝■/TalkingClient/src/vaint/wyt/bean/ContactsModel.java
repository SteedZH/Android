package vaint.wyt.bean;

import vaint.wyt.view.ViewUtils;

import android.graphics.drawable.Drawable;

public class ContactsModel{
	
	private String sortLetters;  	//显示数据拼音的首字母
	private String userId;
	private String name;
	private String gender;
	private Drawable photo;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Drawable getPhoto() {
		return photo;
	}
	public void setPhoto(Drawable photo) {
		this.photo = photo;
	}
	public void setPhoto(String photo) {
		this.photo = ViewUtils.StringToDrawable(photo);
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getSortLetters() {
		return sortLetters;
	}
	public void setSortLetters(String sortLetters) {
		this.sortLetters = sortLetters;
	}
}
