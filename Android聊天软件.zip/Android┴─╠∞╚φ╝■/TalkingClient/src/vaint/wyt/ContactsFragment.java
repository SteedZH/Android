package vaint.wyt;

import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.http.conn.ConnectTimeoutException;
import org.json.JSONObject;

import vaint.wyt.bean.ContactsModel;
import vaint.wyt.bean.FriendList;
import vaint.wyt.bean.User;
import vaint.wyt.constant.Constants;
import vaint.wyt.constant.HandlerID;
import vaint.wyt.db.CacheUtils;
import vaint.wyt.db.DataUtils;
import vaint.wyt.encrypt.EncryptUtils;
import vaint.wyt.http.HttpCallBackListener;
import vaint.wyt.http.HttpUtils;
import vaint.wyt.manage.FriendInfoActivity;
import vaint.wyt.manage.NewFriendsActivity;
import vaint.wyt.msg.MsgUtils;
import vaint.wyt.view.CharacterParser;
import vaint.wyt.view.ContactsAdapter;
import vaint.wyt.view.PinyinComparator;
import vaint.wyt.view.SideBar;
import vaint.wyt.view.SideBar.OnTouchingLetterChangedListener;
import vaint.wyt.view.ViewUtils;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.ListFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

public class ContactsFragment extends ListFragment implements HttpCallBackListener{
	private static final String TAG = ContactsFragment.class.getSimpleName();
	
	private Context mContext; 
	private View mView;
	private LinearLayout mNewFriendsLayout;
	private TextView mNewFriendTips;
	private ListView mFriendListView;
	private SideBar mSideBar;
	private TextView mLetter;
	private ContactsAdapter mAdapter;
	
	private FriendList mFriendList;
	private String mFriendId;
	
	/**好友请求的未读消息提示的广播*/
	private ShowTipsBroadcastReceiver mShowTipsBroadcast;
	/**添加好友的广播*/
	private AddFriendBroadcastReceiver mAddFriendBroadcast;
	
	/**
	 * 汉字转换成拼音的类
	 */
	private CharacterParser mCharacterParser;
	private List<ContactsModel> mSourceDateList;
	
	/**
	 * 根据拼音来排列ListView里面的数据类
	 */
	private PinyinComparator mPinyinComparator;
	
	Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case HandlerID.SHOW_PRO_DIALOG:
				ViewUtils.ShowProgressDialog(mContext,
						(String)msg.obj);
				break;
			case HandlerID.HIDE_PRO_DIALOG:
				ViewUtils.HideProgressDialog();
				break;
			case HandlerID.CONNECT_TIMEOUT_DIALOG:
				ViewUtils.ShowConnectTimeoutDialog(mContext);
				break;
			case HandlerID.SYSTEM_BUSY_DIALOG:
				ViewUtils.ShowSystemBusyDialog(mContext);
				break;
			case HandlerID.SHOW_ERROR_DIALOG:
				ViewUtils.ShowErrorDialog(mContext, (String)msg.obj);
				break;
			}
		}
	};
	
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mContext = getActivity();
		mSourceDateList = new ArrayList<ContactsModel>();
		// 实例化汉字转拼音类
		mCharacterParser = CharacterParser.getInstance();

		mPinyinComparator = new PinyinComparator();
		
		// 注册广播
		mShowTipsBroadcast = new ShowTipsBroadcastReceiver();
		IntentFilter intentFilter1 = new IntentFilter();
		intentFilter1.addAction(Constants.Actions.NEW_FRIEND_TIPS);
		mContext.registerReceiver(mShowTipsBroadcast, intentFilter1);
		
		mAddFriendBroadcast = new AddFriendBroadcastReceiver();
		IntentFilter intentFilter2 = new IntentFilter();
		intentFilter2.addAction(Constants.Actions.CONTACTS_LIST);
		mContext.registerReceiver(mAddFriendBroadcast, intentFilter2);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		mView = inflater.inflate(R.layout.layout_main_contacts, container, false);
		return mView;
	}
	
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		
		findViews();
		setListener();
		
		// 获取好友列表
		mFriendList = DataUtils.GetFriendList();
		// 设置好友列表数据
		mSourceDateList = filledData(mFriendList);

		mAdapter = new ContactsAdapter(mContext, mSourceDateList);
		setListAdapter(mAdapter);
		
		//设置长按监听
		getListView().setOnItemLongClickListener(new ItemLongClickListener());
	}
	
	@Override
	public void onResume() {
		super.onResume();
		//未读消息
		int unread = DataUtils.GetUnreadNewFriends();
		showUnreadTips(unread);
		
		//如果添加好友，要即时更新好友列表
		updateContactsList();
//		// 获取好友列表
//		mFriendList = DataUtils.GetFriendList();
//		// 设置好友列表数据
//		mSourceDateList = filledData(mFriendList);
//
//		mAdapter = new ContactsAdapter(mContext, mSourceDateList);
//		setListAdapter(mAdapter);
		
		//存储当前广播名 回到好友列表界面，则恢复广播
		MsgUtils.SetCurrBroadCast(Constants.Actions.CONTACTS_LIST);
	}
	
	@Override
	public void onPause() {
		super.onPause();
		//清除当前广播名 离开好友列表界面，则暂停广播
		MsgUtils.ClearCurrBroadCast();
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		if(mShowTipsBroadcast!=null)
			mContext.unregisterReceiver(mShowTipsBroadcast);
		if(mAddFriendBroadcast!=null)
			mContext.unregisterReceiver(mAddFriendBroadcast);
	}
	

	private void findViews()
	{
		mNewFriendsLayout = (LinearLayout) mView.findViewById(R.id.contacts_newFriendsLayout);
		mNewFriendTips = (TextView) mView.findViewById(R.id.contact_newFriendTips);
		mSideBar = (SideBar) mView.findViewById(R.id.contacts_sideBar);
		mLetter = (TextView) mView.findViewById(R.id.contacts_letter);
		mSideBar.setTextView(mLetter);
		mFriendListView = getListView();
	}
	
	private void setListener()
	{
		mNewFriendsLayout.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View arg0) {
				mNewFriendTips.setVisibility(View.GONE);
				DataUtils.UpdateUnreadNewFriends(0);
				
				Intent intent = new Intent(mContext, NewFriendsActivity.class);
				startActivity(intent);
			}
		});
		
		// 设置右侧触摸监听
		mSideBar.setOnTouchingLetterChangedListener(new OnTouchingLetterChangedListener() {

			@Override
			public void onTouchingLetterChanged(String s) {
				// 该字母首次出现的位置
				int position = mAdapter.getPositionForSection(s.charAt(0));
				if (position != -1) {
					mFriendListView.setSelection(position);
				}
			}
		});
	}
	
	@Override
	public void onListItemClick(ListView listView, View view, int position, long id) {
		super.onListItemClick(listView, view, position, id);
		Adapter adapter = listView.getAdapter();
		ContactsModel friend = (ContactsModel) adapter.getItem(position);
		User user = new User();
		user.setUserId(friend.getUserId());
		user.setName(friend.getName());
		user.setGender(friend.getGender());
		user.setPhoto(ViewUtils.DrawableToString(friend.getPhoto()));
		
		Intent intent = new Intent(mContext, FriendInfoActivity.class);
		intent.putExtra(Constants.Flags.FRIEND_INFO, user);
		startActivity(intent);
	}
	
	/**更新好友列表ListView*/
	public void updateContactsList()
	{
		//这种做法，会出现头像错乱，还没有找到原因。
		//设置好友列表数据
		mFriendList = DataUtils.GetFriendList();
		mSourceDateList = filledData(mFriendList);
		mAdapter.updateListView(mSourceDateList);
		
//		mFriendList = DataUtils.GetFriendList();
//		mSourceDateList = filledData(mFriendList);
//
//		mAdapter = new ContactsAdapter(mContext, mSourceDateList);
//		setListAdapter(mAdapter);
	}
	
	/**显示未读消息，如果未读消息为0，则隐藏*/
	public void showUnreadTips(int unread)
	{
		if(unread == 0)
		{
			mNewFriendTips.setVisibility(View.GONE);
			mNewFriendTips.setText( "");
		}else
		{
			mNewFriendTips.setText( unread + "");
			mNewFriendTips.setVisibility(View.VISIBLE);
		}
	}

	/**
	 * 为ListView填充数据<BR/>
	 * 已经根据首字母排序
	 * @param date
	 * @return
	 */
	private List<ContactsModel> filledData(FriendList friendList){
		List<ContactsModel> mSortList = new ArrayList<ContactsModel>();
		List<User> friends = friendList.getFriends();
		if(friends == null)
			return mSortList;
		
		for(int i=0; i<friends.size(); i++){
			ContactsModel contactsModel = new ContactsModel();
			User user = friends.get(i);
			contactsModel.setPhoto(user.getPhoto());
			contactsModel.setName(user.getName());
			contactsModel.setGender(user.getGender());
			contactsModel.setUserId(user.getUserId());
			//汉字转换成拼音
			String pinyin = mCharacterParser.getSelling(user.getName());
			String sortString = pinyin.substring(0, 1).toUpperCase();
			
			// 正则表达式，判断首字母是否是英文字母
			if(sortString.matches("[A-Z]")){
				contactsModel.setSortLetters(sortString.toUpperCase());
			}else{
				contactsModel.setSortLetters("#");
			}
			
			mSortList.add(contactsModel);
		}
		// 根据a-z进行排序源数据
		Collections.sort(mSortList, mPinyinComparator);
		return mSortList;
	}


	@Override
	public void httpCallBack(int id, JSONObject resp) {
		mHandler.sendEmptyMessage(HandlerID.HIDE_PRO_DIALOG);
		if(id == Constants.ID.REMOVE_FRIEND)
		{
			Log.d(TAG, "删除好友信息的回调函数");
			String resCode = resp.optString(Constants.ResponseParams.RES_CODE);
			if ("0".equals(resCode))
			{
				Log.d(TAG, "删除好友信息成功");
				
				//删除好友的相关信息
				DataUtils.RemoveFriend(mFriendId);
				//更新好友列表
				updateContactsList();
			}else
			{
				Log.d(TAG, "删除好友信息失败");
				Message msg = new Message();
				msg.what = HandlerID.SHOW_ERROR_DIALOG;
				msg.obj = "删除好友失败";
				mHandler.sendMessage(msg);
			}
		}
	}
	
	
	/**添加好友的未读消息提示的广播*/
	class ShowTipsBroadcastReceiver extends BroadcastReceiver
	{
		@Override
		public void onReceive(Context ctx, Intent intent) {
			int unread = DataUtils.GetUnreadNewFriends() + 1;
			DataUtils.UpdateUnreadNewFriends(unread);
			showUnreadTips(unread);
		}
	}
	/**更新好友列表的广播*/
	class AddFriendBroadcastReceiver extends BroadcastReceiver
	{
		@Override
		public void onReceive(Context ctx, Intent intent) {
			updateContactsList();
		}
	}
	
	class ItemLongClickListener implements OnItemLongClickListener{
		@Override
		public boolean onItemLongClick(AdapterView<?> arg0, View view,
				final int position, long arg3) {
			// 删除好友
			new AlertDialog.Builder(mContext)
					.setTitle(R.string.dialog_title_delfriend)
					.setMessage(R.string.dialog_msg_delfriend)
					.setNegativeButton(R.string.btn_cancel, null)
					.setPositiveButton(R.string.btn_ok,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface arg0,
										int arg1) {

									// 显示进度对话框
									Message msg = new Message();
									msg.what = HandlerID.SHOW_PRO_DIALOG;
									msg.obj = "请稍等...";
									mHandler.sendMessage(msg);

									mFriendId = mSourceDateList.get(position).getUserId();
									JSONObject reqJson = new JSONObject();
									try {
										reqJson.put(
												Constants.RemoveFriend.RequestParams.USER_ID,
												CacheUtils.GetUserId());
										reqJson.put(
												Constants.RemoveFriend.RequestParams.FRIEND_ID,
												mFriendId);

										Log.d(TAG, "删除好友信息请求，加密内容:"
												+ reqJson.toString());
										// RSA 加密
										String data = EncryptUtils
												.GetRsaEncrypt(reqJson
														.toString());
										HttpUtils.sendRequest(
												Constants.ID.REMOVE_FRIEND,
												data,
												ContactsFragment.this);
									} catch (ConnectTimeoutException e) {
										Log.e(TAG, "网络连接超时", e);
										// 提示用户
										mHandler.sendEmptyMessage(HandlerID.HIDE_PRO_DIALOG);
										mHandler.sendEmptyMessage(HandlerID.CONNECT_TIMEOUT_DIALOG);
									} catch (SocketTimeoutException e) {
										Log.e(TAG, "系统繁忙", e);
										// 提示用户
										mHandler.sendEmptyMessage(HandlerID.HIDE_PRO_DIALOG);
										mHandler.sendEmptyMessage(HandlerID.SYSTEM_BUSY_DIALOG);
									} catch (Exception e) {
										e.printStackTrace();
									}
								}
							}).show();
			return false;
		}
		
	}

}
