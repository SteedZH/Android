package vaint.wyt.register;

import java.net.SocketTimeoutException;

import org.apache.http.conn.ConnectTimeoutException;
import org.json.JSONObject;

import vaint.wyt.R;
import vaint.wyt.constant.Constants;
import vaint.wyt.constant.HandlerID;
import vaint.wyt.encrypt.EncryptUtils;
import vaint.wyt.http.HttpCallBackListener;
import vaint.wyt.http.HttpUtils;
import vaint.wyt.login.LoginActivity;
import vaint.wyt.msg.ThreadUtils;
import vaint.wyt.view.ViewUtils;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.Toast;

public class RegisterActivity extends Activity implements HttpCallBackListener {
	private static final String TAG = RegisterActivity.class.getSimpleName();
	
	private static final int ID_GOTO_REGISTER = 101;
	private static final int ID_GOTO_LOGIN = 201;

	private Context mContext;
	private LinearLayout mVerifyCodeLayout;
	private LinearLayout mRegisterLayout;
	private EditText mUserIdEdit;
	private EditText mVerifyCodeEdit;
	private EditText mNameEdit;
	private EditText mPsdEdit;
	private EditText mConformPsdEdit;
	private Button mVerifyCodeBtn;
	private Button mNextBtn;
	private Button mRegisterBtn;
	private RadioGroup mGenderRadioGroup;

	/** 再次获取验证码的间隔时间 */
	private static final int GET_CODE_TIME_SPAN = 60;
	private static int mTime = GET_CODE_TIME_SPAN;
	/** 用户ID号 */
	private String mUserId;
	/** 用户性别 */
	private String mGender = Constants.Gender.MALE;

	private Handler mMultiHandler;
	Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case HandlerID.SHOW_PRO_DIALOG:
				ViewUtils.ShowProgressDialog(mContext,
						(String)msg.obj);
				break;
			case HandlerID.HIDE_PRO_DIALOG:
				ViewUtils.HideProgressDialog();
				break;
			case HandlerID.CONNECT_TIMEOUT_DIALOG:
				ViewUtils.ShowConnectTimeoutDialog(mContext);
				break;
			case HandlerID.SYSTEM_BUSY_DIALOG:
				ViewUtils.ShowSystemBusyDialog(mContext);
				break;
			case HandlerID.SHOW_ERROR_DIALOG:
				ViewUtils.ShowErrorDialog(mContext, (String)msg.obj);
				break;
			case ID_GOTO_REGISTER:
				mRegisterLayout.setVisibility(View.VISIBLE);
				mVerifyCodeLayout.setVisibility(View.GONE);
				stopCount();
				break;
			case ID_GOTO_LOGIN:
				new AlertDialog.Builder(mContext)
				.setMessage(R.string.dialog_msg_register_success)
				.setPositiveButton(R.string.btn_ok,
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog,
									int which) {
								Intent intent = new Intent(
										mContext,
										LoginActivity.class);
								((Activity) mContext).finish();
								startActivity(intent);
							}
						}).show();
				break;
			}
		}
	};

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_register);

		mContext = this;
		mMultiHandler = ThreadUtils.GetMultiHandler(TAG);
				
		findViews();
		setListener();
		
	}

	private void setListener() {
		mGenderRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(RadioGroup radio, int id) {
				if(id == R.id.register_male)
				{
					mGender = Constants.Gender.MALE;
				}
				else if(id == R.id.register_female)
				{
					mGender = Constants.Gender.FEMALE;
				}
			}
		});
		
		mVerifyCodeBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {				
				final String phone = mUserIdEdit.getText().toString();
				if (phone.length() != 11) {
					Toast.makeText(mContext, R.string.toast_phone_len_wrong,
							Toast.LENGTH_SHORT).show();
					return;
				}
				if (!phone.matches("^(13|15|18)\\d{9}$")) {
					Toast.makeText(mContext, R.string.toast_phone_form_wrong,
							Toast.LENGTH_SHORT).show();
					return;
				}

				hideKeyBoard();

				mVerifyCodeBtn.setEnabled(false);

				mHandler.post(mChangeBtnTxtRun);

				// 发起下发验证码请求
				mMultiHandler.post(new Runnable() {
					@Override
					public void run() {
						JSONObject reqJson = new JSONObject();
						try {
							reqJson.put(Constants.Register.RequestParams.PHONE,
									phone);
							Log.d(TAG, "下发验证码请求，加密内容:" + reqJson.toString());
							// RSA 加密
							String data = EncryptUtils.GetRsaEncrypt(reqJson
									.toString());
							Log.d(TAG, "RSA加密数据:"+data);
							HttpUtils.sendRequest(Constants.ID.GET_CODE, data,
									RegisterActivity.this);
						} catch (ConnectTimeoutException e) {
							Log.e(TAG, "网络连接超时", e);
							// 提示用户
							mHandler.sendEmptyMessage(HandlerID.HIDE_PRO_DIALOG);
							mHandler.sendEmptyMessage(HandlerID.CONNECT_TIMEOUT_DIALOG);
						} catch (SocketTimeoutException e) {
							Log.e(TAG, "系统繁忙", e);
							// 提示用户
							mHandler.sendEmptyMessage(HandlerID.HIDE_PRO_DIALOG);
							mHandler.sendEmptyMessage(HandlerID.SYSTEM_BUSY_DIALOG);
						}catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
			}
		});

		mNextBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				
				final String phone = mUserIdEdit.getText().toString();
				final String code = mVerifyCodeEdit.getText().toString();
				if (phone.length() != 11 || code.length() != 6) {
					Toast.makeText(mContext, R.string.toast_phone_code_len_wrong,
							Toast.LENGTH_SHORT).show();
					return;
				}
				if (!phone.matches("^(13|15|18)\\d{9}$")
						|| !code.matches("\\d{6}")) {
					Toast.makeText(mContext, R.string.toast_phone_code_form_wrong,
							Toast.LENGTH_SHORT).show();
					return;
				}

				hideKeyBoard();

				mUserId = phone;

				// 发起校验验证码请求
				mMultiHandler.post(new Runnable() {
					@Override
					public void run() {
						// 显示进度对话框
						Message msg = new Message();
						msg.what = HandlerID.SHOW_PRO_DIALOG;
						msg.obj = "请稍等...";
						mHandler.sendMessage(msg);
						
						JSONObject reqJson = new JSONObject();
						try {
							reqJson.put(Constants.Register.RequestParams.PHONE,
									phone);
							reqJson.put(
									Constants.Register.RequestParams.VERIFY_CODE,
									code);
							reqJson.put(
									Constants.Register.RequestParams.TIMESTAMP,
									System.currentTimeMillis() + "");

							Log.d(TAG, "校验验证码请求，加密内容:" + reqJson.toString());
							// RSA 加密
							String data = EncryptUtils.GetRsaEncrypt(reqJson
									.toString());
							HttpUtils.sendRequest(Constants.ID.CHECK_CODE,
									data, RegisterActivity.this);
						} catch (ConnectTimeoutException e) {
							Log.e(TAG, "网络连接超时", e);
							// 提示用户
							mHandler.sendEmptyMessage(HandlerID.HIDE_PRO_DIALOG);
							mHandler.sendEmptyMessage(HandlerID.CONNECT_TIMEOUT_DIALOG);
						} catch (SocketTimeoutException e) {
							Log.e(TAG, "系统繁忙", e);
							// 提示用户
							mHandler.sendEmptyMessage(HandlerID.HIDE_PRO_DIALOG);
							mHandler.sendEmptyMessage(HandlerID.SYSTEM_BUSY_DIALOG);
						}catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
			}
		});

		mRegisterBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {

				final String name = mNameEdit.getText().toString();
				String psd = mPsdEdit.getText().toString();
				String conPsd = mConformPsdEdit.getText().toString();

				if (name.isEmpty() || psd.isEmpty() || conPsd.isEmpty()) {
					Toast.makeText(mContext, R.string.toast_name_psd_null,
							Toast.LENGTH_SHORT).show();
					return;
				}

				if (!psd.equals(conPsd)) {
					Toast.makeText(mContext, R.string.toast_psd_not_same,
							Toast.LENGTH_SHORT).show();
					return;
				}

				hideKeyBoard();

				// 密码进行MD5加密保存
				final String psdMd5 = EncryptUtils.GetMD5(psd);
				Log.d(TAG, "密码MD5:" + psdMd5);

				// 发起注册请求
				mMultiHandler.post(new Runnable() {
					@Override
					public void run() {
						// 显示进度对话框
						Message msg = new Message();
						msg.what = HandlerID.SHOW_PRO_DIALOG;
						msg.obj = "请稍等...";
						mHandler.sendMessage(msg);
						
						JSONObject reqJson = new JSONObject();
						try {
							reqJson.put(
									Constants.Register.RequestParams.USER_ID,
									mUserId);
							reqJson.put(Constants.Register.RequestParams.NAME,
									name);
							reqJson.put(Constants.Register.RequestParams.GENDER,
									mGender);
							reqJson.put(
									Constants.Register.RequestParams.PASSWORD,
									psdMd5);

							Log.d(TAG, "注册请求，加密内容:" + reqJson.toString());
							// RSA 加密
							String data = EncryptUtils.GetRsaEncrypt(reqJson
									.toString());
							HttpUtils.sendRequest(Constants.ID.REGISTER, data,
									RegisterActivity.this);
						} catch (ConnectTimeoutException e) {
							Log.e(TAG, "网络连接超时", e);
							// 提示用户
							mHandler.sendEmptyMessage(HandlerID.HIDE_PRO_DIALOG);
							mHandler.sendEmptyMessage(HandlerID.CONNECT_TIMEOUT_DIALOG);
						} catch (SocketTimeoutException e) {
							Log.e(TAG, "系统繁忙", e);
							// 提示用户
							mHandler.sendEmptyMessage(HandlerID.HIDE_PRO_DIALOG);
							mHandler.sendEmptyMessage(HandlerID.SYSTEM_BUSY_DIALOG);
						}catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
			}
		});
	}

	private void findViews() {
		mVerifyCodeLayout = (LinearLayout) findViewById(R.id.register_verifyCodeLayout);
		mRegisterLayout = (LinearLayout) findViewById(R.id.register_registerLayout);
		mUserIdEdit = (EditText) findViewById(R.id.register_userID);
		mVerifyCodeEdit = (EditText) findViewById(R.id.register_verifyCode);
		mNameEdit = (EditText) findViewById(R.id.register_username);
		mPsdEdit = (EditText) findViewById(R.id.register_password);
		mConformPsdEdit = (EditText) findViewById(R.id.register_conformPsd);
		mVerifyCodeBtn = (Button) findViewById(R.id.register_verifyBtn);
		mNextBtn = (Button) findViewById(R.id.register_nextBtn);
		mRegisterBtn = (Button) findViewById(R.id.register_registerBtn);
		mGenderRadioGroup = (RadioGroup) findViewById(R.id.register_genderRadio);
	}

	/** 更新获取验证码按钮的文字 */
	Runnable mChangeBtnTxtRun = new Runnable() {
		@Override
		public void run() {
			if (mTime > 0) {
				mVerifyCodeBtn.setText(mTime + "(s)");
				mTime--;
				mHandler.postDelayed(this, 1000);
			} else {
				mVerifyCodeBtn.setText(R.string.btn_verify_again);
				mVerifyCodeBtn.setEnabled(true);
				mTime = GET_CODE_TIME_SPAN;
			}
		}
	};

	/** 隐藏软键盘 */
	private void hideKeyBoard() {
		((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE))
				.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),
						InputMethodManager.HIDE_NOT_ALWAYS);
	}
	
	/**获取验证码按钮停止计数*/
	private void stopCount()
	{
		mHandler.removeCallbacks(mChangeBtnTxtRun);
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		stopCount();
	}

	/** 连接网络成功后的回调函数 */
	@Override
	public void httpCallBack(int id, JSONObject resp) {
		//隐藏进度条
		mHandler.sendEmptyMessage(HandlerID.HIDE_PRO_DIALOG);
		
		switch (id) {
		case Constants.ID.GET_CODE:// 请求验证码
		{
			Log.d(TAG, "请求验证码的回调函数");
			String resCode = resp.optString(Constants.ResponseParams.RES_CODE);
			if ("0".equals(resCode)) {
				Log.d(TAG, "下发验证码的请求成功");
			} else {
				String resMsg = resp
						.optString(Constants.ResponseParams.RES_MSG);
				Log.e(TAG, "下发验证码的请求失败 :" + resMsg);
			}
		}
			break;

		case Constants.ID.CHECK_CODE:// 校验验证码
		{
			
			Log.d(TAG, "校验验证码的回调函数");
			String resCode = resp.optString(Constants.ResponseParams.RES_CODE);
			if ("0".equals(resCode)) {
				Log.d(TAG, "校验验证码成功");

				// 进入注册页面
				mHandler.sendEmptyMessage(ID_GOTO_REGISTER);

			} else {
				String resMsg = resp
						.optString(Constants.ResponseParams.RES_MSG);
				Log.e(TAG, "校验验证码失败 :" + resMsg);

				// 将错误提示用户
				String err = Constants.Register.GetErrorInfo(resCode);
				if (err != null) {
					Message msg = new Message();
					msg.what = HandlerID.SHOW_ERROR_DIALOG;
					msg.obj = err;
					mHandler.sendMessage(msg);
				}
			}
		}
			break;

		case Constants.ID.REGISTER:// 注册
		{
			Log.d(TAG, "注册的回调函数");
			String resCode = resp.optString(Constants.ResponseParams.RES_CODE);
			if ("0".equals(resCode)) {
				Log.d(TAG, "用户" + mUserId + " 注册成功");

				// 进入登录页面
				mHandler.sendEmptyMessage(ID_GOTO_LOGIN);
			} else {
				String resMsg = resp
						.optString(Constants.ResponseParams.RES_MSG);
				Log.e(TAG, "注册失败 :" + resMsg);

				String err = Constants.Register.GetErrorInfo(resCode);
				if (err != null) {
					Message msg = new Message();
					msg.what = HandlerID.SHOW_ERROR_DIALOG;
					msg.obj = err;
					mHandler.sendMessage(msg);
				}
			}
		}
			break;
		}
	}
}
