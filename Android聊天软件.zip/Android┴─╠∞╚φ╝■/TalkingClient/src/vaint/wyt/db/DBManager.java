package vaint.wyt.db;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import vaint.wyt.bean.ChatListModel;
import vaint.wyt.bean.ChattingModel;
import vaint.wyt.bean.FriendList;
import vaint.wyt.bean.NewFriendsModel;
import vaint.wyt.bean.User;
import vaint.wyt.constant.Constants;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class DBManager {
	private static final String NAME_PREFERENCE = "vaint.wyt.db";
	private static final String KEY_UNREAD_NEW_FRIENDS = "vaint.wyt.unread_new_friends";

	private Context mContext;
	private DBHelper mDBHelper;
	private SQLiteDatabase mSQLite;
	/** 存储好友请求的未读消息数目 */
	private SharedPreferences mSharedPref;

	public DBManager(Context context, String userId) {
		mContext = context;
		mDBHelper = new DBHelper(mContext, userId);
		// 因为getWritableDatabase内部调用了mContext.openOrCreateDatabase(mName, 0,
		// mFactory);
		// 所以要确保context已初始化,我们可以把实例化DBManager的步骤放在Activity的onCreate里
		mSQLite = mDBHelper.getWritableDatabase();

		mSharedPref = mContext.getSharedPreferences(NAME_PREFERENCE,
				Context.MODE_PRIVATE);
	}

	/** 关闭数据库 */
	public void closeSQLite() {
		if (mSQLite != null)
			mSQLite.close();
	}

	/************************************* 好友列表 ****************************************/
	/*
	 * 好友列表数据库格式 friends表 friend_id name gender photo
	 */
	/**
	 * 更新好友列表<BR/>
	 * 参数由服务器端提供。覆盖更新
	 * 
	 * @param json
	 *            格式{num:X,friends:{0:[id,name,gender,photo],..}
	 */
	public void UpdateFriendList(JSONObject json) {
		// 清空好友列表旧数据
		mSQLite.delete(DBHelper.FRIENDS, null, null);

		int num = json.optInt(Constants.GetFriendList.JsonKey.NUM);
		JSONObject friendsJson = json
				.optJSONObject(Constants.GetFriendList.JsonKey.FRIENDS);
		JSONArray friendArr;

		// 开启事务
		mSQLite.beginTransaction();
		try {
			for (int i = 0; i < num; i++) {
				friendArr = friendsJson.optJSONArray(i + "");
				// friends表 friend_id name gender photo
				mSQLite.execSQL(
						"INSERT INTO " + DBHelper.FRIENDS
								+ " VALUES(?, ?, ?, ?)",
						new Object[] { friendArr.optString(0),
								friendArr.optString(1), friendArr.optString(2),
								friendArr.optString(3) });
			}
			// 设置事务成功，不设置则回滚不提交
			mSQLite.setTransactionSuccessful();
		} finally {
			// 结束事务
			mSQLite.endTransaction();
		}
	}

	/**
	 * 更新好友列表的头像和昵称<BR/>
	 * 参数一般从缓存获取
	 */
	public void UpdateFriendList(FriendList friendList) {
		List<User> list = friendList.getFriends();
		User friend;
		// 开启事务
		mSQLite.beginTransaction();
		try {
			for (int i = 0; i < list.size(); i++) {
				friend = list.get(i);
				// friends表 friend_id name gender photo
				mSQLite.execSQL("INSERT INTO " + DBHelper.FRIENDS
						+ " VALUES(?, ?, ?, ?)",
						new Object[] { friend.getUserId(), friend.getName(),
								friend.getGender(), friend.getPhoto() });
			}
			// 设置事务成功，不设置则回滚不提交
			mSQLite.setTransactionSuccessful();
		} finally {
			// 结束事务
			mSQLite.endTransaction();
		}
	}

	/** 获得好友列表 */
	public FriendList GetFriendList() {
		FriendList friends = new FriendList();
		List<User> list = new ArrayList<User>();

		// 查询所有的好友列表信息
		Cursor cursor = mSQLite.rawQuery("SELECT * FROM " + DBHelper.FRIENDS,
				null);
		while (cursor.moveToNext()) {
			User user = new User();
			user.setUserId(cursor.getString(cursor.getColumnIndex("friend_id")));
			user.setName(cursor.getString(cursor.getColumnIndex("name")));
			user.setGender(cursor.getString(cursor.getColumnIndex("gender")));
			user.setPhoto(cursor.getString(cursor.getColumnIndex("photo")));

			list.add(user);
		}
		cursor.close();
		friends.setFriends(list);
		return friends;
	}

	/************************************* 聊天列表 ****************************************/
	/*
	 * chat_list表 friend_id , unread , content , time
	 */

	/** 获得聊天列表信息 */
	public List<ChatListModel> GetChatList() {
		List<ChatListModel> chatList = new ArrayList<ChatListModel>();

		// 查询所有聊天列表数据
		Cursor cursor = mSQLite.rawQuery("SELECT * FROM " + DBHelper.CHAT_LIST,
				null);

		while (cursor.moveToNext()) {
			ChatListModel model = new ChatListModel();
			// friend_id , unread , content , time
			String friendId = cursor.getString(cursor.getColumnIndex("friend_id"));
			model.setFriendId(friendId);
			model.setContent(cursor.getString(cursor.getColumnIndex("content")));
			model.setTime(cursor.getString(cursor.getColumnIndex("time")));
			model.setUnread(cursor.getInt(cursor.getColumnIndex("unread")));
			//ChatListModel的title和photo需要从friends表中获取
			Cursor c = mSQLite.rawQuery("SELECT * FROM " + DBHelper.FRIENDS + " WHERE friend_id=?",
					new String[]{friendId});
			if(c.moveToNext())
			{
				model.setTitle(c.getString(c.getColumnIndex("name")));
				model.setPhoto(c.getString(c.getColumnIndex("photo")));
			}

			chatList.add(model);
		}
		cursor.close();

		return chatList;
	}

	/** 更新聊天列表信息 覆盖更新 */
	public void UpdateChatList(List<ChatListModel> chatList) {

		// 清空原来的聊天列表数据
		mSQLite.delete(DBHelper.CHAT_LIST, null, null);

		ChatListModel model;
		// 开启事务
		mSQLite.beginTransaction();
		try {
			for (int i = 0; i < chatList.size(); i++) {
				model = chatList.get(i);
				// friend_id , unread , content , time 
				mSQLite.execSQL(
						"INSERT INTO " + DBHelper.CHAT_LIST
								+ " VALUES(?, ?, ?, ?)",
						new Object[] { model.getFriendId(), model.getUnread(),
								model.getContent(), model.getTime()});
			}
			// 设置事务成功，不设置则回滚不提交
			mSQLite.setTransactionSuccessful();
		} finally {
			// 结束事务
			mSQLite.endTransaction();
		}
	}

	/************************************* 聊天记录 ****************************************/
	/*
	 * 表名就是 chatting_好友ID 加上前缀是因为数据库表名，不能以数字字符串开头 id , time , msg, send ,
	 * show_time
	 */
	/**
	 * 获得对应好友的聊天记录
	 * 
	 * @return 新的消息在后面
	 */
	public List<ChattingModel> GetChattingList(String friendId) {
		// 如果该好友的聊天记录表不存在，则会创建
		mDBHelper.createChattingTable(mSQLite, DBHelper.CHATTING_PREFIX
				+ friendId);

		List<ChattingModel> list = new ArrayList<ChattingModel>();
		String photo = "";
		// 查询该好友的昵称和头像
		Cursor cursor1 = mSQLite.rawQuery("SELECT * FROM " + DBHelper.FRIENDS
				+ " WHERE friend_id=?", new String[] { friendId });
		if (cursor1.moveToNext()) {
			photo = cursor1.getString(cursor1.getColumnIndex("photo"));
		}
		cursor1.close();

		// 查询该好友的聊天记录
		Cursor cursor2 = mSQLite.rawQuery("SELECT * FROM "
				+ DBHelper.CHATTING_PREFIX + friendId, null);
		while (cursor2.moveToNext()) {
			ChattingModel model = new ChattingModel();
			model.setPhoto(photo);
			// id , time , msg, send , show_time
			model.setTime(cursor2.getString(cursor2.getColumnIndex("time")));
			model.setMsg(cursor2.getString(cursor2.getColumnIndex("msg")));
			model.setSend(cursor2.getInt(cursor2.getColumnIndex("send")));
			model.setShowTime(cursor2.getInt(cursor2
					.getColumnIndex("show_time")));

			list.add(0, model);
		}
		cursor2.close();
		return list;
	}

	/**
	 * 更新聊天记录信息，覆盖更新<BR/>
	 * List<ChattingModel>的记录 最新的消息在后面
	 */
	public void UpdateChattingList(String friendId, List<ChattingModel> list) {
		// 如果该好友的聊天记录表不存在，则会创建
		mDBHelper.createChattingTable(mSQLite, DBHelper.CHATTING_PREFIX
				+ friendId);

		ChattingModel model;

		// 开启事务
		mSQLite.beginTransaction();
		try {
			// 逆向取出数据保存
			for (int i = list.size() - 1; i >= 0; i--) {
				model = list.get(i);
				// id , time , msg, send , show_time
				int send = model.isSend() ? 1 : 0;
				int showTime = model.isShowTime() ? 1 : 0;
				mSQLite.execSQL("INSERT INTO " + DBHelper.CHATTING_PREFIX
						+ friendId + " VALUES(null, ?, ?, ?, ?)", new Object[] {
						model.getTime(), model.getMsg(), send, showTime });
			}
			// 设置事务成功，不设置则回滚不提交
			mSQLite.setTransactionSuccessful();
		} finally {
			// 结束事务
			mSQLite.endTransaction();
		}
	}

	/** 删除对应好友的聊天记录 */
	public void RemoveChattingList(String friendId) {
		// 如果该好友的聊天记录表不存在，则会创建
		mDBHelper.createChattingTable(mSQLite, DBHelper.CHATTING_PREFIX
				+ friendId);

		mSQLite.delete(DBHelper.CHATTING_PREFIX + friendId, null, null);
	}

	/************************************* 好友请求列表 ****************************************/
	/*
	 * new_friends表 user_id , name , verify_msg , time, is_agree, photo
	 */
	/** 获得好友请求的列表 */
	public List<NewFriendsModel> GetNewFriendsList() {
		List<NewFriendsModel> list = new ArrayList<NewFriendsModel>();

		// 查询该好友的聊天记录
		Cursor cursor = mSQLite.rawQuery("SELECT * FROM "
				+ DBHelper.NEW_FRIENDS, null);
		while (cursor.moveToNext()) {
			NewFriendsModel model = new NewFriendsModel();

			// user_id , name , gender, verify_msg , time, is_agree, photo
			model.setUserId(cursor.getString(cursor.getColumnIndex("user_id")));
			model.setName(cursor.getString(cursor.getColumnIndex("name")));
			model.setGender(cursor.getString(cursor.getColumnIndex("gender")));
			model.setVerifyMsg(cursor.getString(cursor
					.getColumnIndex("verify_msg")));
			model.setTime(cursor.getString(cursor.getColumnIndex("time")));
			model.setAgreed(cursor.getInt(cursor.getColumnIndex("is_agree")));
			model.setPhoto(cursor.getString(cursor.getColumnIndex("photo")));

			list.add(model);
		}
		cursor.close();
		return list;
	}

	/** 更新好友请求列表 覆盖更新 */
	public void UpdateNewFriendsList(List<NewFriendsModel> list) {
		// 清空旧数据
		mSQLite.delete(DBHelper.NEW_FRIENDS, null, null);

		NewFriendsModel model;

		// 开启事务
		mSQLite.beginTransaction();
		try {
			for (int i = 0; i < list.size(); i++) {
				model = list.get(i);
				// user_id , name , gender , verify_msg , time, is_agree, photo
				int isAgree = model.isAgreed() ? 1 : 0;

				mSQLite.execSQL("INSERT INTO " + DBHelper.NEW_FRIENDS
						+ " VALUES(?, ?, ?, ?, ?, ?, ?)",
						new Object[] { model.getUserId(), model.getName(), model.getGender(),
								model.getVerifyMsg(), model.getTime(), isAgree,
								model.getPhotoString() });
			}
			// 设置事务成功，不设置则回滚不提交
			mSQLite.setTransactionSuccessful();
		} finally {
			// 结束事务
			mSQLite.endTransaction();
		}
	}

	/** 清空好友请求列表 */
	public void ClearNewFriendsList() {
		// 清空旧数据
		mSQLite.delete(DBHelper.NEW_FRIENDS, null, null);
	}

	/** 获得好友请求的未读消息 */
	public int GetUnreadNewFriends() {
		int unread = mSharedPref.getInt(KEY_UNREAD_NEW_FRIENDS, 0);
		return unread;
	}

	/** 更新好友请求的未读消息 */
	public void UpdateUnreadNewFriends(int unread) {
		Editor editor = mSharedPref.edit();
		editor.putInt(KEY_UNREAD_NEW_FRIENDS, unread);
		editor.commit();
	}
}
