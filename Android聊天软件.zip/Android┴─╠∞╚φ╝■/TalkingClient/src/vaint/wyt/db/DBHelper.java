package vaint.wyt.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper{
	private static final int DATABASE_VERSION = 1;
	
	/**好友列表 表名*/
	public static final String FRIENDS = "friends";
	/**聊天列表 表名*/
	public static final String CHAT_LIST = "chat_list";
	/**好友请求 表名*/
	public static final String NEW_FRIENDS = "new_friends";
	/**聊天记录表名前缀*/
	public static final String CHATTING_PREFIX = "chatting_";
	
	
	/**@param userId 以当前用户ID作为数据库名称*/
	public DBHelper(Context context,String userId) {
		//CursorFactory设置为null,使用默认值
		super(context, userId, null, DATABASE_VERSION);
	}

	//数据库第一次被创建时onCreate会被调用
	@Override
	public void onCreate(SQLiteDatabase db) {
		//好友列表
		db.execSQL("CREATE TABLE IF NOT EXISTS " + FRIENDS + " (friend_id VARCHAR(20) PRIMARY KEY, name VARCHAR(25), gender VARCHAR(10), photo TEXT)");
		//聊天列表
		db.execSQL("CREATE TABLE IF NOT EXISTS  " + CHAT_LIST + " (friend_id VARCHAR(20) PRIMARY KEY, unread INTEGER, content VARCHAR(20), time VARCHAR(10))");
		//好友请求列表
		db.execSQL("CREATE TABLE IF NOT EXISTS  " + NEW_FRIENDS + " (user_id VARCHAR(20) PRIMARY KEY, name VARCHAR(25), gender VARCHAR(10), verify_msg VARCHAR(20), time VARCHAR(10), is_agree INTEGER, photo TEXT)");
	}
	
	/**创建对应好友的聊天记录表*/
	public void createChattingTable(SQLiteDatabase db, String dbName)
	{
		db.execSQL("CREATE TABLE IF NOT EXISTS " + dbName + " (id INTEGER PRIMARY KEY AUTOINCREMENT, time VARCHAR(10), msg TEXT, send INTEGER, show_time INTEGER)");
	}
	
	

	//如果DATABASE_VERSION值被修改,系统发现现有数据库版本不同,即会调用onUpgrade
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		
	}

}
