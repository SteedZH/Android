package vaint.wyt.db;

import java.util.List;

import org.json.JSONObject;

import android.content.Context;

import vaint.wyt.bean.ChatListModel;
import vaint.wyt.bean.ChattingModel;
import vaint.wyt.bean.FriendList;
import vaint.wyt.bean.NewFriendsModel;
import vaint.wyt.bean.User;

/**
 * 数据处理工具类<BR/>
 * 缓存与数据库数据之间的配合使用<BR/>
 * 数据的增删一般由缓存处理，比较方便。然后将数据提供给数据库工具类，进行存储
 * @author Vaint
 *@E-mail vaintwyt@163.com
 *
 */
public class DataUtils {
	private static DBManager mDBManager;
	/**初始化数据库工具*/
	public static void Init(Context ctx, String userId)
	{
		mDBManager = new DBManager(ctx, userId);
	}
	
	/**关闭数据库*/
	public static void Close()
	{
		mDBManager.closeSQLite();
	}
	
	/********************好友列表**************************/
	/**更新好友列表<BR/>参数由服务端提供，将会覆盖原来的好友列表数据*/
	public static void UpdateFriendList(JSONObject json)
	{
		CacheUtils.UpdateFriendList(json);
		mDBManager.UpdateFriendList(json);
	}

	/**更新好友列表*/
	public static void UpdateFriendList(FriendList friendList)
	{
		CacheUtils.UpdateFriendList(friendList);
		mDBManager.UpdateFriendList(friendList);
	}
	
	/**添加一个好友*/
	public static void AddFriend(User user)
	{
		FriendList friendList = CacheUtils.AddFriend(user);
		mDBManager.UpdateFriendList(friendList);
	}
	
	/**删除一个好友<BR/>同时删除聊天列表对应项和聊天记录*/
	public static void RemoveFriend(String friendId)
	{
		//好友列表
		FriendList friendList = CacheUtils.RemoveFriend(friendId);
		mDBManager.UpdateFriendList(friendList);
		//聊天列表和聊天记录
		RemoveChat(friendId);
	}
	
	/**获得好友列表*/
	public static FriendList GetFriendList()
	{
		FriendList friendList = CacheUtils.GetFriendList();
		if(friendList == null)//缓存中没有数据
		{
			friendList = mDBManager.GetFriendList();
			CacheUtils.UpdateFriendList(friendList);
		}
		return friendList;
	}
	
	/**获得对应好友的信息<BR/>对应好友不存在，则返回null*/
	public static User GetFriend(String friendId)
	{
		User user = CacheUtils.GetFriend(friendId);
		if(user == null)
		{
			//从本地获取设置缓存数据
			CacheUtils.UpdateFriendList(mDBManager.GetFriendList());
		}
		//再次获取
		user = CacheUtils.GetFriend(friendId);
		return user;
	}
	
	
	/********************聊天列表**************************/
	/**更新一条聊天会话,如果之前不存在，则新建*/
	public static List<ChatListModel> UpdateChatList(String friendId, ChatListModel model)
	{
		List<ChatListModel> chatList = CacheUtils.UpdateChatList(friendId, model);
		mDBManager.UpdateChatList(chatList);
		return chatList;
	}
	
	/** 根据好友列表信息更新聊天会话信息。如头像和昵称 */
	public static void UpdateChatListInfo(FriendList friendList)
	{
		List<ChatListModel> chatList = CacheUtils.UpdateChatList(friendList);
		if(chatList!=null)
		{
			mDBManager.UpdateChatList(chatList);
		}
	}
	
	/**删除一个聊天会话<BR/>同时删除聊天记录*/
	public static void RemoveChat(String friendId)
	{
		//删除聊天列表中的对应会话
		boolean ret = CacheUtils.RemoveChat(friendId);
		if(ret)//聊天会话存在
		{
			//聊天会话
			mDBManager.UpdateChatList(CacheUtils.GetChatList());
			//删除聊天记录
			RemoveChattingList(friendId);
		}
		
	}
	
	/**获得聊天列表*/
	public static List<ChatListModel> GetChatList()
	{
		List<ChatListModel> chatList = CacheUtils.GetChatList();
		if(chatList == null)
		{
			chatList = mDBManager.GetChatList();
			CacheUtils.UpdateChatList(chatList);
		}
		return chatList;
	}


	/********************聊天记录**************************/
	/**获得与该好友的聊天记录*/
	public static List<ChattingModel> GetChattingList(String friendId)
	{
		List<ChattingModel> chattingList = CacheUtils.GetChattingList(friendId);
		if(chattingList == null)
		{
			chattingList = mDBManager.GetChattingList(friendId);
			CacheUtils.UpdateChattingList(friendId, chattingList);
		}
		return chattingList;
	}
	
	/**更新与该好友的聊天消息<BR/>覆盖更新*/
	public static void UpdateChattingList(String friendId, List<ChattingModel> chattingList)
	{
		CacheUtils.UpdateChattingList(friendId, chattingList);
		mDBManager.UpdateChattingList(friendId, chattingList);
	}
	
	/**添加一条聊天消息，可选择是否本地化*/
	public static void AddChattingItem(String friendId, ChattingModel model, boolean isChangeFile)
	{
		List<ChattingModel> list = CacheUtils.AddChattingItem(friendId, model);
		if(isChangeFile)
		{
			mDBManager.UpdateChattingList(friendId, list);
		}
	}
	
	/**删除对应的聊天记录*/
	public static void RemoveChattingList(String friendId)
	{
		CacheUtils.RemoveChattingList(friendId);
		mDBManager.RemoveChattingList(friendId);
	}
	
	
	/********************新的好友**************************/
	/**更新好友请求数据*/
	public static void UpdateNewFriendsList(List<NewFriendsModel> list)
	{
		CacheUtils.UpdateNewFriendsList(list);
		mDBManager.UpdateNewFriendsList(list);
	}
	
	/**获得好友请求的未读消息数目*/
	public static int GetUnreadNewFriends()
	{
		int unread = CacheUtils.GetUnreadNewFriends();
		if(unread == -1)
		{
			unread = mDBManager.GetUnreadNewFriends();
			CacheUtils.UpdateUnreadNewFriends(unread);
		}
		return unread;
	}
	
	/**更新好友请求的未读消息数目*/
	public static void UpdateUnreadNewFriends(int unread)
	{
		CacheUtils.UpdateUnreadNewFriends(unread);
		mDBManager.UpdateUnreadNewFriends(unread);
	}
	
	/**获得好友请求列表*/
	public static List<NewFriendsModel> GetNewFriendsList()
	{
		List<NewFriendsModel> list = CacheUtils.GetNewFriendsList();
		if(list == null)
		{
			list = mDBManager.GetNewFriendsList();
			CacheUtils.UpdateNewFriendsList(list);
		}
		return list;
	}
	
	/**清空好友请求列表*/
	public static void ClearNewFriendsList()
	{
		CacheUtils.ClearNewFriendsList();
		mDBManager.ClearNewFriendsList();
	}
	
	
}

