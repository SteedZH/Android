package vaint.wyt.manage;

import java.io.File;
import java.net.SocketTimeoutException;

import org.apache.http.conn.ConnectTimeoutException;
import org.json.JSONObject;

import vaint.wyt.R;
import vaint.wyt.bean.User;
import vaint.wyt.constant.Constants;
import vaint.wyt.constant.HandlerID;
import vaint.wyt.db.CacheUtils;
import vaint.wyt.db.FileUtils;
import vaint.wyt.encrypt.EncryptUtils;
import vaint.wyt.http.HttpCallBackListener;
import vaint.wyt.http.HttpUtils;
import vaint.wyt.msg.ThreadUtils;
import vaint.wyt.view.ViewUtils;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class UserInfoActivity extends Activity implements HttpCallBackListener{
	private static final String TAG = UserInfoActivity.class.getSimpleName();
	
	private static final int ALBUM_RET_CODE = 1;
	private static final int CAMERA_RET_CODE = 2;
	private static final int FINISH_RET_CODE = 3;
	private static final String PHOTO_NAME = "talking_photo.jpg";

	private Context mContext;
	private ImageView mPhotoImage;
	private EditText mNameEdit;
	private RadioGroup mGenderRadioGroup;
	private RadioButton mMaleRadio;
	private RadioButton mFemaleRadio;
	private Button mSaveBtn;
	private Button mModifyPsdBtn;
	private Button mBackBtn;
	
	/**用于判断信息是否被修改，如果没有修改，则不需要上传更新*/
	private boolean mIsModifyPhoto;
	private String mPhoto;
	private String mGender;

	private Handler mMultiHandler;
	Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case HandlerID.SHOW_PRO_DIALOG:
				ViewUtils.ShowProgressDialog(mContext,
						(String)msg.obj);
				break;
			case HandlerID.HIDE_PRO_DIALOG:
				ViewUtils.HideProgressDialog();
				break;
			case HandlerID.CONNECT_TIMEOUT_DIALOG:
				ViewUtils.ShowConnectTimeoutDialog(mContext);
				break;
			case HandlerID.SYSTEM_BUSY_DIALOG:
				ViewUtils.ShowSystemBusyDialog(mContext);
				break;
			case HandlerID.SHOW_ERROR_DIALOG:
				ViewUtils.ShowErrorDialog(mContext, (String)msg.obj);
				break;
			}
		}
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_menu_userinfo);
		mContext = this;
		mMultiHandler = ThreadUtils.GetMultiHandler(TAG);
		
		findViews();
		//设置原有头像和昵称 在setListener之前.因为我们需要监听头像是否被修改，以便设置保存按钮的可用
		User user = CacheUtils.GetUserCache();
		if(user != null)
		{
			Drawable drawable = ViewUtils.StringToDrawable(user.getPhoto());
			if(drawable!=null)
			{
				mPhotoImage.setImageDrawable(drawable);
			}
			mNameEdit.setText(user.getName());
			if(Constants.Gender.MALE.equals(user.getGender()))//男
			{
				mMaleRadio.setChecked(true);
			}
			else//女
			{
				mFemaleRadio.setChecked(true);
			}
		}
		
		setListener();
	}

	private void setListener() {
		mPhotoImage.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				new AlertDialog.Builder(mContext)
						.setTitle(R.string.dialog_title_photo)
						.setSingleChoiceItems(
								new String[] {
										mContext.getString(R.string.dialog_str_album),
										mContext.getString(R.string.dialog_str_camera) },
								0, new DialogInterface.OnClickListener() {
									public void onClick(DialogInterface dialog,
											int which) {
										dialog.dismiss();
										switch (which) {
										case 0:// 相册
										{
											Intent intent = new Intent(
													Intent.ACTION_PICK, null);
											intent.setDataAndType(
													MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
													"image/*");
											startActivityForResult(intent,
													ALBUM_RET_CODE);
										}
											break;
										case 1:// 相机
										{
											// 判断存储卡是否可以用，可用进行存储
											if (!FileUtils.HasSdCard()) {
												Toast.makeText(
														mContext,
														R.string.toast_sdcard_invalid,
														Toast.LENGTH_SHORT)
														.show();
												return;
											}
											Intent intent = new Intent(
													MediaStore.ACTION_IMAGE_CAPTURE);
											intent.putExtra(
													MediaStore.EXTRA_OUTPUT,
													Uri.fromFile(new File(
															Environment
																	.getExternalStorageDirectory(),
															PHOTO_NAME)));
											startActivityForResult(intent,
													CAMERA_RET_CODE);
										}
											break;
										}
									}
								}).setNegativeButton(R.string.btn_cancel, null)
						.show();
			}
		});
		
		
		//监听昵称是否被修改
		mNameEdit.addTextChangedListener(new TextWatcher() {
			public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
				mSaveBtn.setEnabled(true);
			}
			public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
					int arg3) {
			}
			public void afterTextChanged(Editable arg0) {
			}
		});
		
		mGenderRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(RadioGroup arg0, int id) {
				//设置保存按钮可用
				mSaveBtn.setEnabled(true);
			}
		});

		mSaveBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View arg0) {
				final String name = mNameEdit.getText().toString();
				
				if(name.equals(""))
				{
					Toast.makeText(mContext, R.string.toast_name_null, Toast.LENGTH_SHORT).show();
					return;
				}
				
				/*
				 * 如果头像被修改，获取照片字符串
				 * 
				 * data格式:
				 * 更新头像 data=RSA字符串&photo字串
				 * 不用更新头像 data=RSA字符串&
				 */
				if(mIsModifyPhoto)
				{
					//获得头像字符串
//					mPhotoImage.setDrawingCacheEnabled(true);
//					Bitmap bmp = mPhotoImage.getDrawingCache();
					mPhoto = ViewUtils.DrawableToString(mPhotoImage.getDrawable());
//					mPhotoImage.setDrawingCacheEnabled(false);
					Log.d(TAG, "修改用户信息请求，photo长度" + mPhoto.length() + " photo=" + mPhoto);
				}else
				{
					mPhoto = "";
				}
				
				hideKeyBoard();
				
				//发起修改用户信息的请求
				mMultiHandler.post(new Runnable(){
					public void run() {
						// 显示进度对话框
						Message msg = new Message();
						msg.what = HandlerID.SHOW_PRO_DIALOG;
						msg.obj = "正在保存...";
						mHandler.sendMessage(msg);

						if(mMaleRadio.isChecked())//男
						{
							mGender = Constants.Gender.MALE;
						}
						else
						{
							mGender = Constants.Gender.FEMALE;
						}
						
						JSONObject reqJson = new JSONObject();
						try {
							reqJson.put(
									Constants.UserInfo.RequestParams.USER_ID,
									CacheUtils.GetUserId());
							reqJson.put(Constants.UserInfo.RequestParams.NAME,
									name);
							reqJson.put(Constants.UserInfo.RequestParams.GENDER,
									mGender);

							Log.d(TAG, "修改用户信息请求，加密内容:" + reqJson.toString());
							// RSA 加密
							String data = EncryptUtils.GetRsaEncrypt(reqJson
									.toString());
							//将photo数据添加到data中，以便在HttpUtils处理
							data = data + "&" + mPhoto;
							HttpUtils.sendRequest(Constants.ID.MODIFY_USERINFO, data,
									UserInfoActivity.this);
						} catch (ConnectTimeoutException e) {
							Log.e(TAG, "网络连接超时", e);
							// 提示用户
							mHandler.sendEmptyMessage(HandlerID.HIDE_PRO_DIALOG);
							mHandler.sendEmptyMessage(HandlerID.CONNECT_TIMEOUT_DIALOG);
						} catch (SocketTimeoutException e) {
							Log.e(TAG, "系统繁忙", e);
							// 提示用户
							mHandler.sendEmptyMessage(HandlerID.HIDE_PRO_DIALOG);
							mHandler.sendEmptyMessage(HandlerID.SYSTEM_BUSY_DIALOG);
						}catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
			}
		});

		mModifyPsdBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View arg0) {
				Intent intent = new Intent(mContext, ModifyPsdActivity.class);
				startActivity(intent);
			}
		});
		mBackBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View arg0) {
				((Activity) mContext).finish();
			}
		});
	}

	private void findViews() {
		mPhotoImage = (ImageView) findViewById(R.id.userInfo_photoImage);
		mNameEdit = (EditText) findViewById(R.id.userInfo_name);
		mGenderRadioGroup = (RadioGroup) findViewById(R.id.userInfo_genderRadio);
		mMaleRadio = (RadioButton) findViewById(R.id.userInfo_male);
		mFemaleRadio = (RadioButton) findViewById(R.id.userInfo_female);
		mModifyPsdBtn = (Button) findViewById(R.id.userInfo_modifyPsdBtn);
		mBackBtn = (Button) findViewById(R.id.userInfo_backBtn);
		mSaveBtn = (Button) findViewById(R.id.userInfo_saveBtn);
	}

	/**
	 * 裁剪图片方法实现 　　
	 * 
	 * @param uri
	 *            　　
	 */
	public void startPhotoZoom(Uri uri) {
		Intent intent = new Intent("com.android.camera.action.CROP");
		intent.setDataAndType(uri, "image/*");
		// 下面这个crop=true是设置在开启的Intent中设置显示的view可裁剪
		intent.putExtra("crop", "true");
		// aspectX aspectY 是宽高的比例
		intent.putExtra("aspectX", 1);
		intent.putExtra("aspectY", 1);
		// outputX outputY 是裁剪图片宽高
		intent.putExtra("outputX", 150);
		intent.putExtra("outputY", 150);
		intent.putExtra("return-data", true);
		startActivityForResult(intent, FINISH_RET_CODE);
	}

	/**
	 * 保存裁剪之后的图片数据 　　
	 * 
	 * @param picdata
	 */
	private void setPicToView(Intent picdata) {
		Bundle extras = picdata.getExtras();
		if (extras != null) {
			Bitmap photo = extras.getParcelable("data");
			Drawable drawable = new BitmapDrawable(photo);
			mPhotoImage.setImageDrawable(drawable);
		}
	}

	/** 隐藏软键盘 */
	private void hideKeyBoard() {
		((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE))
				.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),
						InputMethodManager.HIDE_NOT_ALWAYS);
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode != RESULT_CANCELED) {
			switch (requestCode) {
			// 从相册获取
			case ALBUM_RET_CODE:
				startPhotoZoom(data.getData());
				break;
			// 相机拍照
			case CAMERA_RET_CODE:
				File temp = new File(Environment.getExternalStorageDirectory()
						+ "/" + PHOTO_NAME);
				startPhotoZoom(Uri.fromFile(temp));
				break;
			// 取得裁剪后的图片
			case FINISH_RET_CODE:
				/**
				 * 非空判断一定要验证
				*如果不验证的话,在剪裁之后如果发现不满意，要重新裁剪，丢弃当前功能时，会报NullException
				 */
				if (data != null) {
					setPicToView(data);
					//头像被修改,需要上传头像进行更新
					mIsModifyPhoto = true;
					mSaveBtn.setEnabled(true);
				}
				break;
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	/**连接网络成功后的回调函数 */
	@Override
	public void httpCallBack(int id, JSONObject resp) {
		//隐藏进度条
		mHandler.sendEmptyMessage(HandlerID.HIDE_PRO_DIALOG);
		if(id == Constants.ID.MODIFY_USERINFO)
		{
			Log.d(TAG, "修改用户信息的回调函数");
			String resCode = resp.optString(Constants.ResponseParams.RES_CODE);
			if ("0".equals(resCode))
			{
				Log.d(TAG, "修改用户信息成功");
				
				//更新缓存
				CacheUtils.SetUserName(mNameEdit.getText().toString());
				CacheUtils.SetGender(mGender);
				if(mIsModifyPhoto)
					CacheUtils.SetUserPhoto(mPhoto);
				
				mHandler.post(new Runnable() {
					@Override
					public void run() {
						mSaveBtn.setEnabled(false);
						mIsModifyPhoto = false;
						
						new AlertDialog.Builder(mContext)
						.setMessage(R.string.dialog_msg_modify_success)
						.setPositiveButton(R.string.btn_ok,
								new DialogInterface.OnClickListener() {
									@Override
									public void onClick(DialogInterface dialog,
											int which) {
										((Activity) mContext).finish();
									}
								}).show();
					}
				});
			}
			else
			{
				String resMsg = resp
						.optString(Constants.ResponseParams.RES_MSG);
				Log.e(TAG, "修改用户信息失败 :" + resMsg);

				String err = Constants.UserInfo.GetErrorInfo(resCode);
				if (err != null) {
					Message msg = new Message();
					msg.what = HandlerID.SHOW_ERROR_DIALOG;
					msg.obj = err;
					mHandler.sendMessage(msg);
				}
			}
			
		}
		
	}

}
