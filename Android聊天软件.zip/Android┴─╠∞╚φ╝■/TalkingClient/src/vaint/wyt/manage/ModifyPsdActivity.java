package vaint.wyt.manage;

import java.net.SocketTimeoutException;

import org.apache.http.conn.ConnectTimeoutException;
import org.json.JSONObject;

import vaint.wyt.MainActivity;
import vaint.wyt.R;
import vaint.wyt.constant.Constants;
import vaint.wyt.constant.HandlerID;
import vaint.wyt.db.CacheUtils;
import vaint.wyt.encrypt.EncryptUtils;
import vaint.wyt.http.HttpCallBackListener;
import vaint.wyt.http.HttpUtils;
import vaint.wyt.msg.ThreadUtils;
import vaint.wyt.view.ViewUtils;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ModifyPsdActivity extends Activity implements HttpCallBackListener{
	private static final String TAG = ModifyPsdActivity.class.getSimpleName();
	
	private static final int ID_MODIFY_SUCCESS = 101;
	
	private Context mContext;
	private EditText mOldPsdEdit;
	private EditText mNewPsdEdit;
	private EditText mConPsdEdit;
	private Button mSaveBtn;
	private Button mBackBtn;
	
	private Handler mMultiHandler;
	Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case HandlerID.SHOW_PRO_DIALOG:
				ViewUtils.ShowProgressDialog(mContext,
						(String)msg.obj);
				break;
			case HandlerID.HIDE_PRO_DIALOG:
				ViewUtils.HideProgressDialog();
				break;
			case HandlerID.CONNECT_TIMEOUT_DIALOG:
				ViewUtils.ShowConnectTimeoutDialog(mContext);
				break;
			case HandlerID.SYSTEM_BUSY_DIALOG:
				ViewUtils.ShowSystemBusyDialog(mContext);
				break;
			case HandlerID.SHOW_ERROR_DIALOG:
				ViewUtils.ShowErrorDialog(mContext, (String)msg.obj);
				break;
			case ID_MODIFY_SUCCESS:
				new AlertDialog.Builder(mContext)
				.setMessage(R.string.dialog_msg_modify_success)
				.setPositiveButton(R.string.btn_ok,
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog,
									int which) {
								Intent intent = new Intent(
										mContext,
										MainActivity.class);
								((Activity) mContext).finish();
								startActivity(intent);
							}
						}).show();
				break;
			}
		}
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_menu_modify_psd);
		mContext = this;
		mMultiHandler = ThreadUtils.GetMultiHandler(TAG);
		findViews();
		setListener();
	}
	
	private void setListener()
	{
		mSaveBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View arg0) {
				String oldPsd = mOldPsdEdit.getText().toString();
				String newPsd = mNewPsdEdit.getText().toString();
				String conPsd =  mConPsdEdit.getText().toString();
				
				if(TextUtils.isEmpty(oldPsd) || TextUtils.isEmpty(newPsd) ||TextUtils.isEmpty(conPsd))
				{
					Toast.makeText(mContext, R.string.toast_psd_null, Toast.LENGTH_SHORT).show();
					return;
				}
				
				if(!newPsd.equals(conPsd))
				{
					Toast.makeText(mContext, R.string.toast_psd_not_same, Toast.LENGTH_SHORT).show();
					return;
				}
				
				hideKeyBoard();
				
				final String oldPsdMd5 = EncryptUtils.GetMD5(oldPsd);
				final String newPsdMd5 = EncryptUtils.GetMD5(newPsd);
				
				//发起修改密码的请求
				mMultiHandler.post(new Runnable() {
					@Override
					public void run() {
						// 显示进度对话框
						Message msg = new Message();
						msg.what = HandlerID.SHOW_PRO_DIALOG;
						msg.obj = "正在保存...";
						mHandler.sendMessage(msg);

						JSONObject reqJson = new JSONObject();
						try {
							reqJson.put(
									Constants.UserInfo.RequestParams.USER_ID,
									CacheUtils.GetUserId());
							reqJson.put(
									Constants.UserInfo.RequestParams.OLD_PSD,
									oldPsdMd5);
							reqJson.put(
									Constants.UserInfo.RequestParams.PASSWORD,
									newPsdMd5);

							Log.d(TAG, "修改登录密码请求，加密内容:" + reqJson.toString());
							// RSA 加密
							String data = EncryptUtils.GetRsaEncrypt(reqJson
									.toString());
							HttpUtils.sendRequest(Constants.ID.MODIFY_PSD,
									data, ModifyPsdActivity.this);
						} catch (ConnectTimeoutException e) {
							Log.e(TAG, "网络连接超时", e);
							// 提示用户
							mHandler.sendEmptyMessage(HandlerID.HIDE_PRO_DIALOG);
							mHandler.sendEmptyMessage(HandlerID.CONNECT_TIMEOUT_DIALOG);
						} catch (SocketTimeoutException e) {
							Log.e(TAG, "系统繁忙", e);
							// 提示用户
							mHandler.sendEmptyMessage(HandlerID.HIDE_PRO_DIALOG);
							mHandler.sendEmptyMessage(HandlerID.SYSTEM_BUSY_DIALOG);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
				
			}
		});
		
		mBackBtn.setOnClickListener(new View.OnClickListener() {
			public void onClick(View arg0) {
				((Activity) mContext).finish();
			}
		});
	}
	
	private void findViews()
	{
		mOldPsdEdit = (EditText) findViewById(R.id.modifyPsd_oldPsd);
		mNewPsdEdit = (EditText) findViewById(R.id.modifyPsd_newPsd);
		mConPsdEdit = (EditText) findViewById(R.id.modifyPsd_conPsd);
		mSaveBtn = (Button) findViewById(R.id.modifyPsd_saveBtn);
		mBackBtn = (Button) findViewById(R.id.modifyPsd_backBtn);
	}
	
	/** 隐藏软键盘 */
	private void hideKeyBoard() {
		((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE))
				.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),
						InputMethodManager.HIDE_NOT_ALWAYS);
	}

	/**网络连接成功后的回调函数*/
	@Override
	public void httpCallBack(int id, JSONObject resp) {
		//隐藏进度条
		mHandler.sendEmptyMessage(HandlerID.HIDE_PRO_DIALOG);
		switch (id) {
		case Constants.ID.MODIFY_PSD:
			Log.d(TAG, "修改登录密码的回调函数");
			String resCode = resp.optString(Constants.ResponseParams.RES_CODE);
			if ("0".equals(resCode)) {
				Log.d(TAG, "修改用户信息成功");
				mHandler.sendEmptyMessage(ID_MODIFY_SUCCESS);
			} else {
				String resMsg = resp
						.optString(Constants.ResponseParams.RES_MSG);
				Log.e(TAG, "修改登录密码失败 :" + resMsg);

				String err = Constants.UserInfo.GetErrorInfo(resCode);
				if (err != null) {
					Message msg = new Message();
					msg.what = HandlerID.SHOW_ERROR_DIALOG;
					msg.obj = err;
					mHandler.sendMessage(msg);
				}
			}
			break;
		}
	}
}
