package vaint.wyt.manage;

import java.net.SocketTimeoutException;

import org.apache.http.conn.ConnectTimeoutException;
import org.json.JSONObject;

import vaint.wyt.R;
import vaint.wyt.bean.ChatData;
import vaint.wyt.bean.ChatData.Type;
import vaint.wyt.bean.User;
import vaint.wyt.constant.Constants;
import vaint.wyt.constant.HandlerID;
import vaint.wyt.db.CacheUtils;
import vaint.wyt.encrypt.EncryptUtils;
import vaint.wyt.http.HttpCallBackListener;
import vaint.wyt.http.HttpUtils;
import vaint.wyt.msg.MsgUtils;
import vaint.wyt.msg.ThreadUtils;
import vaint.wyt.view.ShowPhotoActivity;
import vaint.wyt.view.ViewUtils;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class AddFriendActivity extends Activity implements HttpCallBackListener{
	private static final String TAG = AddFriendActivity.class.getSimpleName();
	
	private Context mContext;
	private EditText mSearchIdEdit;
	private Button mSearchBtn;
	private LinearLayout mUserInfoLayout;
	private ImageView mPhotoImage;
	private ImageView mGenderImage;
	private TextView mUserId;
	private TextView mUserName;
	private EditText mVerifyMsgEdit;
	private Button mAddFriendBtn;
	private Button mBackBtn;

	private Handler mMultiHandler;
	Handler mMainHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case HandlerID.SHOW_PRO_DIALOG:
				ViewUtils.ShowProgressDialog(mContext,
						(String)msg.obj);
				break;
			case HandlerID.HIDE_PRO_DIALOG:
				ViewUtils.HideProgressDialog();
				break;
			case HandlerID.CONNECT_TIMEOUT_DIALOG:
				ViewUtils.ShowConnectTimeoutDialog(mContext);
				break;
			case HandlerID.SYSTEM_BUSY_DIALOG:
				ViewUtils.ShowSystemBusyDialog(mContext);
				break;
			case HandlerID.SHOW_ERROR_DIALOG:
				ViewUtils.ShowErrorDialog(mContext, (String)msg.obj);
				break;
			}
		}
	};
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_menu_add_friend);
		mContext = this;
		mMultiHandler = ThreadUtils.GetMultiHandler(TAG);
		findViews();
		setListener();
	}
	
	private void setListener()
	{
		mSearchBtn.setOnClickListener(new View.OnClickListener() {
			public void onClick(View arg0) {
				final String searchId = mSearchIdEdit.getText().toString();
				if(searchId.length() != 11)
				{
					Toast.makeText(mContext, R.string.toast_phone_len_wrong, Toast.LENGTH_SHORT).show();
					return;
				}
				
				if(!searchId.matches("^(13|15|18)\\d{9}$"))
				{
					Toast.makeText(mContext, R.string.toast_phone_form_wrong,
							Toast.LENGTH_SHORT).show();
					return;
				}
				
				hideKeyBoard();
				
				//新开启线程处理
				mMultiHandler.post(new Runnable() {
					public void run() {
						// 显示进度对话框
						Message msg = new Message();
						msg.what = HandlerID.SHOW_PRO_DIALOG;
						msg.obj = "正在搜索...";
						mMainHandler.sendMessage(msg);
						JSONObject reqJson = new JSONObject();
						try {
							reqJson.put(Constants.AddFriend.RequestParams.USER_ID, searchId);
							
							Log.d(TAG, "搜索好友请求，加密内容:" + reqJson.toString());
							// RSA 加密
							String data = EncryptUtils.GetRsaEncrypt(reqJson
									.toString());
							HttpUtils.sendRequest(Constants.ID.SEARCH_USER, data,
									AddFriendActivity.this);
						} catch (ConnectTimeoutException e) {
							Log.e(TAG, "网络连接超时", e);
							// 提示用户
							mMainHandler.sendEmptyMessage(HandlerID.HIDE_PRO_DIALOG);
							mMainHandler.sendEmptyMessage(HandlerID.CONNECT_TIMEOUT_DIALOG);
						} catch (SocketTimeoutException e) {
							Log.e(TAG, "系统繁忙", e);
							// 提示用户
							mMainHandler.sendEmptyMessage(HandlerID.HIDE_PRO_DIALOG);
							mMainHandler.sendEmptyMessage(HandlerID.SYSTEM_BUSY_DIALOG);
						}catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
			}
		});
		
		//点击头像，放大显示
		mPhotoImage.setOnTouchListener(new View.OnTouchListener() {
			public boolean onTouch(View arg0, MotionEvent arg1) {
				Intent intent = new Intent(mContext, ShowPhotoActivity.class);
				Bitmap bmp  = ((BitmapDrawable) mPhotoImage.getDrawable()).getBitmap();
				intent.putExtra("SHOW_PHOTO", bmp);
				startActivity(intent);
				return false;
			}
		});
		
		mAddFriendBtn.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				final String userId = mUserId.getText().toString();
				final String verifyMsg = mVerifyMsgEdit.getText().toString();
				
				//判断是否为本用户
				if(userId.equals(CacheUtils.GetUserId()))
				{
					Message msg = new Message();
					msg.what = HandlerID.SHOW_ERROR_DIALOG;
					msg.obj = "不能添加自己为好友";
					mMainHandler.sendMessage(msg);
					return;
				}
				
				//根据ID判断是否已经为好友
				User user = CacheUtils.GetFriend(userId);
				if(user != null)
				{
					Message msg = new Message();
					msg.what = HandlerID.SHOW_ERROR_DIALOG;
					msg.obj = "该用户已经是你的好友";
					mMainHandler.sendMessage(msg);
					return;
				}
				
				Message msg = new Message();
				msg.what = HandlerID.SHOW_PRO_DIALOG;
				msg.obj = "请稍等...";
				mMainHandler.sendMessage(msg);
				
				// 异步发送消息给好友
				mMultiHandler.post(new Runnable() {
					public void run() {
						ChatData.MSG Msg = new ChatData.MSG();
						Msg.setType(Type.ADD_FRIEND);
						Msg.setFromId(CacheUtils.GetUserId());
						Msg.setToId(userId);
						Msg.setTime(MsgUtils.GetFormatTime());
						Msg.setMsg(verifyMsg);
						//添加本用户的信息
						Msg.setPhoto(ViewUtils.DrawableToString(CacheUtils.GetUserPhoto()));
						Msg.setName(CacheUtils.GetUserName());
						Msg.setGender(CacheUtils.GetGender());
						
						MsgUtils.SendMsg(Msg);
					}
				});
				
				//恢复界面
				mMainHandler.post(new Runnable() {
					public void run() {
						mUserInfoLayout.setVisibility(View.GONE);
						mPhotoImage.setImageDrawable(getResources().getDrawable(R.drawable.photo_default));
						mUserId.setText("");
						mUserName.setText("");
						mVerifyMsgEdit.setText("");
						
						mSearchIdEdit.setText("");
					}
				});
				
				mMainHandler.sendEmptyMessage(HandlerID.HIDE_PRO_DIALOG);
				Toast.makeText(mContext, R.string.toast_add_friend, Toast.LENGTH_LONG).show();
			}
		});
		
		mBackBtn.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				((Activity) mContext).finish();
			}
		});
	}
	

	private void findViews()
	{
		mSearchIdEdit = (EditText) findViewById(R.id.addFriend_searchId);
		mSearchBtn = (Button) findViewById(R.id.addFriend_searchBtn);
		mUserInfoLayout = (LinearLayout) findViewById(R.id.addFriend_userInfoLayout);
		mPhotoImage = (ImageView) findViewById(R.id.addFriend_photo);
		mGenderImage= (ImageView) findViewById(R.id.addFriend_gender);
		mUserId = (TextView) findViewById(R.id.addFriend_userId);
		mUserName = (TextView) findViewById(R.id.addFriend_userName);
		mVerifyMsgEdit = (EditText) findViewById(R.id.addFriend_verifyMsg);
		mAddFriendBtn = (Button) findViewById(R.id.addFriend_addBtn);
		mBackBtn = (Button) findViewById(R.id.addFriend_backBtn);
	}
	
	/** 隐藏软键盘 */
	private void hideKeyBoard() {
		((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE))
				.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),
						InputMethodManager.HIDE_NOT_ALWAYS);
	}
	
	@Override
	public void httpCallBack(int id, final JSONObject resp) {
		//隐藏进度条
		mMainHandler.sendEmptyMessage(HandlerID.HIDE_PRO_DIALOG);
		switch(id){
		case Constants.ID.SEARCH_USER:
		{
			Log.d(TAG, "请求搜索信息的回调函数");
			String resCode = resp.optString(Constants.ResponseParams.RES_CODE);
			if ("0".equals(resCode)) {
				Log.d(TAG, "请求搜索信息成功");
				
				//更新界面
				mMainHandler.post(new Runnable() {
					public void run() {
						mUserId.setText(resp.optString(Constants.AddFriend.ResponseParams.USER_ID));
						mUserName.setText(resp.optString(Constants.AddFriend.ResponseParams.NAME));
						String gender = resp.optString(Constants.AddFriend.ResponseParams.GENDER);
						if(Constants.Gender.FEMALE.equals(gender))//女 默认为男性图标
						{
							mGenderImage.setImageDrawable(getResources().getDrawable(R.drawable.gender_female));
						}
						
						String photo = resp.optString(Constants.AddFriend.ResponseParams.PHOTO);
						if(!photo.isEmpty())
						{
							mPhotoImage.setImageDrawable(ViewUtils.StringToDrawable(photo));
						}
						mUserInfoLayout.setVisibility(View.VISIBLE);
					}
				});
			}else
			{
				String resMsg = resp
						.optString(Constants.ResponseParams.RES_MSG);
				Log.d(TAG, "请求搜索信息失败："+resMsg);
				String err = Constants.AddFriend.GetErrorInfo(resCode);
				if (err != null) {
					Message msg = new Message();
					msg.what = HandlerID.SHOW_ERROR_DIALOG;
					msg.obj = err;
					mMainHandler.sendMessage(msg);
				}
			}
		}
		break;
		}
	}

}
