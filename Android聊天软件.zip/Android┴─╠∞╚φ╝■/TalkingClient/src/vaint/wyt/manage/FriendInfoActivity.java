package vaint.wyt.manage;

import java.net.SocketTimeoutException;

import org.apache.http.conn.ConnectTimeoutException;
import org.json.JSONObject;

import vaint.wyt.ChattingActivity;
import vaint.wyt.R;
import vaint.wyt.bean.User;
import vaint.wyt.constant.Constants;
import vaint.wyt.constant.HandlerID;
import vaint.wyt.db.CacheUtils;
import vaint.wyt.db.DataUtils;
import vaint.wyt.encrypt.EncryptUtils;
import vaint.wyt.http.HttpCallBackListener;
import vaint.wyt.http.HttpUtils;
import vaint.wyt.msg.ThreadUtils;
import vaint.wyt.view.ShowPhotoActivity;
import vaint.wyt.view.ViewUtils;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class FriendInfoActivity extends ActionBarActivity implements HttpCallBackListener{
	private static final String TAG = FriendInfoActivity.class.getSimpleName();
	
	private Context mContext;
	private ActionBar mActionBar;
	private ImageView mPhotoImage;
	private ImageView mGenderImage;
	private TextView mUserId;
	private TextView mUserName;
	private Button mSendMsgBtn;
	private Button mBackBtn;
	private Drawable mPhoto;
	
	private User mUser;

	private Handler mMultiHandler;
	Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case HandlerID.SHOW_PRO_DIALOG:
				ViewUtils.ShowProgressDialog(mContext,
						(String)msg.obj);
				break;
			case HandlerID.HIDE_PRO_DIALOG:
				ViewUtils.HideProgressDialog();
				break;
			case HandlerID.CONNECT_TIMEOUT_DIALOG:
				ViewUtils.ShowConnectTimeoutDialog(mContext);
				break;
			case HandlerID.SYSTEM_BUSY_DIALOG:
				ViewUtils.ShowSystemBusyDialog(mContext);
				break;
			case HandlerID.SHOW_ERROR_DIALOG:
				ViewUtils.ShowErrorDialog(mContext, (String)msg.obj);
				break;
			}
		}
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_contacts_friend);
		
		mContext = this;
		mMultiHandler = ThreadUtils.GetMultiHandler(TAG);
		mActionBar = getSupportActionBar();
		mActionBar.setDisplayShowTitleEnabled(false);
		
		findViews();
		setListener();
		
		Intent intent = getIntent();
		mUser = (User) intent.getSerializableExtra(Constants.Flags.FRIEND_INFO);
		mPhoto = ViewUtils.StringToDrawable(mUser.getPhoto());
		if(mPhoto != null)
		{
			mPhotoImage.setImageDrawable(mPhoto);
		}
		mUserId.setText(mUser.getUserId());
		mUserName.setText(mUser.getName());
		if(Constants.Gender.FEMALE.equals(mUser.getGender()))
		{
			mGenderImage.setImageDrawable(getResources().getDrawable(R.drawable.gender_female));
		}
	}
	
	private void setListener()
	{
		mPhotoImage.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View arg0, MotionEvent arg1) {
				Intent intent = new Intent(mContext, ShowPhotoActivity.class);
				Bitmap bmp = null;
				if(mPhoto != null)
				{
					bmp = ((BitmapDrawable) mPhoto).getBitmap();
				}
				intent.putExtra(Constants.Flags.SHOW_PHOTO, bmp);
				startActivity(intent);
				return false;
			}
		});
		
		mSendMsgBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				//打开聊天会话
				Intent intent = new Intent(mContext, ChattingActivity.class);
				intent.putExtra(Constants.Flags.CHATTING_FRIEND, mUser);
				((Activity) mContext).finish();
				startActivity(intent);
			}
		});
		
		mBackBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				((Activity) mContext).finish();
			}
		});
	}
	
	private void findViews()
	{
		mPhotoImage = (ImageView) findViewById(R.id.friendInfo_photo);
		mGenderImage = (ImageView) findViewById(R.id.friendInfo_gender);
		mUserId = (TextView) findViewById(R.id.friendInfo_userId);
		mUserName = (TextView) findViewById(R.id.friendInfo_userName);
		mSendMsgBtn = (Button) findViewById(R.id.friendInfo_sendMsgBtn);
		mBackBtn = (Button) findViewById(R.id.friendInfo_backBtn);
	}
	
	/**添加ActionBar的Menu*/
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.menu_friend_info, menu);
		return super.onCreateOptionsMenu(menu);
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if(item.getItemId()==R.id.friendInfo_menu_delFriend)
		{
			//删除好友
			new AlertDialog.Builder(mContext)
			.setTitle(R.string.dialog_title_delfriend).setMessage(R.string.dialog_msg_delfriend)
			.setNegativeButton(R.string.btn_cancel, null)
			.setPositiveButton(R.string.btn_ok, new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface arg0, int arg1) {
					
					mMultiHandler.post(new Runnable() {
						@Override
						public void run() {
							// 显示进度对话框
							Message msg = new Message();
							msg.what = HandlerID.SHOW_PRO_DIALOG;
							msg.obj = "请稍等...";
							mHandler.sendMessage(msg);
							
							JSONObject reqJson = new JSONObject();
							try {
								reqJson.put(
										Constants.RemoveFriend.RequestParams.USER_ID,
										CacheUtils.GetUserId());
								reqJson.put(Constants.RemoveFriend.RequestParams.FRIEND_ID,
										mUserId.getText().toString());
								
								Log.d(TAG, "删除好友信息请求，加密内容:" + reqJson.toString());
								// RSA 加密
								String data = EncryptUtils.GetRsaEncrypt(reqJson
										.toString());
								HttpUtils.sendRequest(Constants.ID.REMOVE_FRIEND, data,
										FriendInfoActivity.this);
							} catch (ConnectTimeoutException e) {
								Log.e(TAG, "网络连接超时", e);
								// 提示用户
								mHandler.sendEmptyMessage(HandlerID.HIDE_PRO_DIALOG);
								mHandler.sendEmptyMessage(HandlerID.CONNECT_TIMEOUT_DIALOG);
							} catch (SocketTimeoutException e) {
								Log.e(TAG, "系统繁忙", e);
								// 提示用户
								mHandler.sendEmptyMessage(HandlerID.HIDE_PRO_DIALOG);
								mHandler.sendEmptyMessage(HandlerID.SYSTEM_BUSY_DIALOG);
							}catch (Exception e) {
								e.printStackTrace();
							}
							
						}
					});
					
				}
			}).show();
		}
		return false;
	}

	@Override
	public void httpCallBack(int id, JSONObject resp) {
		mHandler.sendEmptyMessage(HandlerID.HIDE_PRO_DIALOG);
		if(id == Constants.ID.REMOVE_FRIEND)
		{
			Log.d(TAG, "删除好友信息的回调函数");
			String resCode = resp.optString(Constants.ResponseParams.RES_CODE);
			if ("0".equals(resCode))
			{
				Log.d(TAG, "删除好友信息成功");
				final String friendId = mUserId.getText().toString();
				//删除好友及相关信息
				mMultiHandler.post(new Runnable() {
					@Override
					public void run() {
						DataUtils.RemoveFriend(friendId);
					}
				});
				
				//退出界面
				((Activity) mContext).finish();
			}else
			{
				Log.d(TAG, "删除好友信息失败");
				Message msg = new Message();
				msg.what = HandlerID.SHOW_ERROR_DIALOG;
				msg.obj = "删除好友失败";
				mHandler.sendMessage(msg);
			}
		}
	}
}
