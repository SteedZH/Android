package vaint.wyt.manage;

import java.util.List;

import vaint.wyt.R;
import vaint.wyt.bean.NewFriendsModel;
import vaint.wyt.constant.Constants;
import vaint.wyt.db.DataUtils;
import vaint.wyt.msg.MsgUtils;
import vaint.wyt.view.NewFriendsAdapter;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;

public class NewFriendsActivity extends ActionBarActivity {
//	private static final String TAG = NewFriendsActivity.class.getSimpleName();
	
	private Context mContext;
	private ListView mListView;
	private NewFriendsAdapter mAdapter;
	private List<NewFriendsModel> mSourceDateList;

	Handler mHandler = new Handler();
	private MsgBroadcastReceiver mBroadcast;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_new_friends);
		mContext = this;
		mListView = (ListView) findViewById(R.id.newFriends_listView);
		mSourceDateList = DataUtils.GetNewFriendsList();
		mAdapter = new NewFriendsAdapter(mContext, mSourceDateList);
		mListView.setAdapter(mAdapter);
		
		// 注册更新聊天列表的广播
		mBroadcast = new MsgBroadcastReceiver();
		IntentFilter intentFilter = new IntentFilter();
		intentFilter.addAction(Constants.Actions.NEW_FRIEND_LIST);
		mContext.registerReceiver(mBroadcast, intentFilter);
		
		MsgUtils.SetCurrBroadCast(Constants.Actions.NEW_FRIEND_LIST);
	}
	
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		if(mBroadcast!=null)
			mContext.unregisterReceiver(mBroadcast);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.menu_new_friends, menu);
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.newFriends_menu_clear:
			// 清空消息
			mHandler.post(new Runnable() {
				@Override
				public void run() {
					new AlertDialog.Builder(mContext)
							.setMessage(R.string.dialog_msg_clear_new_friend)
							.setNegativeButton(R.string.btn_cancel, null)
							.setPositiveButton(R.string.btn_ok, new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog, int which) {
									 DataUtils.ClearNewFriendsList();
									 mSourceDateList.clear();
									 mAdapter.updateListView(mSourceDateList);
								}
							}).show();
				}
			});
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}
	
	/**更新好友请求列表的广播*/
	class MsgBroadcastReceiver extends BroadcastReceiver
	{
		@Override
		public void onReceive(Context ctx, Intent intent) {
			mSourceDateList = DataUtils.GetNewFriendsList();
			mAdapter.updateListView(mSourceDateList);
		}
	}
}
