package vaint.wyt.view;

import java.util.ArrayList;
import java.util.List;

import vaint.wyt.R;
import vaint.wyt.bean.SmileyFacial;
import vaint.wyt.msg.FacialUtils;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.text.SpannableString;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

/**
 * 带有表情和发送按钮的输入框布局
 * @author Vaint
 *@E-mail vaintwyt@163.com
 *
 */
public class FacialEditLayout extends LinearLayout implements OnItemClickListener, OnClickListener{
	
	private Context mContext;
	
    /**发送按钮的监听事件 */  
    private OnSendBtnClickListener mSendBtnListener;  
  
    /** 显示表情页的viewpager */  
    private ViewPager mFacialViewPager;  
    /** 表情页界面集合 */  
    private ArrayList<View> mPageViews;  
    /** 游标显示布局 */  
    private LinearLayout mCursorLayout;  
    /** 游标点集合 */  
    private ArrayList<ImageView> mCursorViews;  
    /** 表情集合 页+个 */  
    private List<List<SmileyFacial>> smileys;  
    /** 表情区域 */  
    private View mFacialLayout;  
    /** 打开或关闭表情的按钮 */  
    private ImageView mFacialEnable;
    /** 输入框 */  
    private EditText mMsgEdit; 
    /**发送按钮*/
    private Button mSendBtn;
    /** 表情数据填充器 */  
    private List<FacialAdapter> mFacialAdapters;  
    /** 当前表情页 */  
    private int current = 0;
    
    /**一页表情框的的表情个数*/
//    private static final int NUM_PER_PAGE = 20;
    /**表情的列数*/
    private static final int COLUMNS = 7;
    /**表情的行数*/   
    private  static final int ROWS = 3;
  
    /**游标的宽高*/
    private static final int CURSOR_DIMEN = 12;
    /**整个表情布局的高度，包含表情框，游标*/
    private int mFacialLayoutHeight;
    /**表情ViewPager的高度*/
    private int mFacialViewPagerHeight;
    /**每个表情的高度*/
    private int mFacialHeight;
    /**每个表情的宽度*/
    private int mFacialWidth;
    

	public FacialEditLayout(Context context) {
		super(context);
		mContext = context;
		LayoutInflater.from(mContext).inflate(R.layout.facial_edit_layout, this);
	}

	public FacialEditLayout(Context context, AttributeSet attrs) {  
        super(context, attrs);  
        mContext = context;
        LayoutInflater.from(mContext).inflate(R.layout.facial_edit_layout, this);
    }
	
	/*****************************对外接口 start*********************************/
	/**发送按钮点击监听*/
	public interface OnSendBtnClickListener {  
		/**
		 * @param 
		 * input 编辑框的输入
		 */
		void onBtnClicked(String input);  
	}
	
	/**设置按钮点击监听器*/
	public void setOnSendBtnClickListener(OnSendBtnClickListener listener) {  
		mSendBtnListener = listener;
	}
	/**获得编辑框的输入字串*/
	public String getMsgEditTxt()
	{
		return mMsgEdit.getText().toString();
	}
	/**清空编辑框*/
	public void clearMsgEdit()
	{
		mMsgEdit.setText("");
	}
	/**判断表情框是否显示<BR/>一般用于重写返回按键时调用*/
	public boolean isFacialShow()
	{
		return (mFacialLayout.getVisibility() == View.VISIBLE);
	}
	/** 隐藏表情选择框<BR/>一般用于重写返回按键时调用 */  
    public void hideFacialView() {  
        if (mFacialLayout.getVisibility() == View.VISIBLE) { 
        	mFacialEnable.setImageDrawable(getResources().getDrawable(R.drawable.facial_btn_normal));
        	mFacialLayout.setVisibility(View.GONE);  
        }  
    }
	
	
	/*****************************对外接口 end*********************************/
	
	
	@Override  
    protected void onFinishInflate() {  
        super.onFinishInflate();  
        onCreate();  
    }
	
	private void onCreate() {  
        initView();  
        initViewPager();  
        initCursor();  
        initData();
    }
	
	/** 
     * 初始化控件 
     */  
    private void initView() {
    	mFacialEnable = (ImageView) findViewById(R.id.facial_enable);  
    	mMsgEdit = (EditText) findViewById(R.id.facial_edit);  
    	mSendBtn = (Button) findViewById(R.id.facial_sendBtn);
    	mFacialLayout = findViewById(R.id.facial_facialLayout);  
        mFacialViewPager = (ViewPager) findViewById(R.id.facial_viewPager);  
        mCursorLayout = (LinearLayout) findViewById(R.id.facial_cursor);  
        mMsgEdit.setOnClickListener(this);
        mFacialEnable.setOnClickListener(this);
        mSendBtn.setOnClickListener(this);

        //获得屏幕宽度
        WindowManager wm = (WindowManager) getContext()
                .getSystemService(Context.WINDOW_SERVICE);
        int screenWidth = wm.getDefaultDisplay().getWidth();
        //每个表情的宽高
        mFacialWidth = screenWidth / COLUMNS - 1;
        mFacialHeight = mFacialWidth;
        //表情框高度
        mFacialViewPagerHeight = mFacialHeight * ROWS + 20;
        //整个表情布局高度
        mFacialLayoutHeight = mFacialViewPagerHeight + CURSOR_DIMEN + 30;
        
        RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) mFacialViewPager.getLayoutParams();
        lp.height = mFacialViewPagerHeight;
        mFacialViewPager.setLayoutParams(lp);
        
        LinearLayout.LayoutParams lp1 = (LayoutParams) mFacialLayout.getLayoutParams();
        lp1.height = mFacialLayoutHeight;
        mFacialLayout.setLayoutParams(lp1);
        
        smileys = FacialUtils.getInstace().getFacialData();
    }
    
    /**
	 * 初始化显示表情的viewpager
	 */
	private void initViewPager() {
		mPageViews = new ArrayList<View>();
		// 左侧添加空页
		View nullView1 = new View(mContext);
		// 设置透明背景
		nullView1.setBackgroundColor(Color.TRANSPARENT);
		mPageViews.add(nullView1);

		// 中间添加表情页
		mFacialAdapters = new ArrayList<FacialAdapter>();
		for (int i = 0; i < smileys.size(); i++) {
			GridView view = new GridView(mContext);
			FacialAdapter adapter = new FacialAdapter(mContext, smileys.get(i), mFacialWidth, mFacialWidth);
			view.setAdapter(adapter);
			mFacialAdapters.add(adapter);
			view.setOnItemClickListener(this);
			view.setNumColumns(COLUMNS);//列数
			view.setBackgroundColor(Color.TRANSPARENT);
			view.setHorizontalSpacing(1);
			view.setVerticalSpacing(1);
			view.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
			view.setCacheColorHint(0);
			view.setPadding(5, 0, 5, 0);
			view.setSelector(new ColorDrawable(Color.TRANSPARENT));
			view.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,
					LayoutParams.WRAP_CONTENT));
			view.setGravity(Gravity.CENTER);
			mPageViews.add(view);
		}

		// 右侧添加空页面
		View nullView2 = new View(mContext);
		// 设置透明背景
		nullView2.setBackgroundColor(Color.TRANSPARENT);
		mPageViews.add(nullView2);
	}
	
	/**
	 * 初始化游标
	 */
	private void initCursor() {
		mCursorViews = new ArrayList<ImageView>();
		ImageView imageView;
		for (int i = 0; i < mPageViews.size(); i++) {
			imageView = new ImageView(mContext);
			imageView.setBackgroundResource(R.drawable.facial_cursor_normal);
			LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
					new ViewGroup.LayoutParams(LayoutParams.WRAP_CONTENT,
							LayoutParams.WRAP_CONTENT));
			layoutParams.leftMargin = 10;
			layoutParams.rightMargin = 10;
			layoutParams.width = CURSOR_DIMEN;
			layoutParams.height = CURSOR_DIMEN;
			mCursorLayout.addView(imageView, layoutParams);
			if (i == 0 || i == mPageViews.size() - 1) {
				imageView.setVisibility(View.GONE);
			}
			if (i == 1) {
				imageView.setBackgroundResource(R.drawable.facial_cursor_selected);
			}
			mCursorViews.add(imageView);
		}
	}
	
	/**
	 * 填充数据
	 */
	private void initData() {
		mFacialViewPager.setAdapter(new ViewPagerAdapter(mPageViews));

		mFacialViewPager.setCurrentItem(1);
		current = 0;
		mFacialViewPager.setOnPageChangeListener(new OnPageChangeListener() {
			@Override
			public void onPageSelected(int position) {
				current = position - 1;
				// 描绘分页点
				drawCursor(position);
				// 如果是第一屏或者是最后一屏禁止滑动，其实这里实现的是如果滑动的是第一屏则跳转至第二屏，如果是最后一屏则跳转到倒数第二屏.
				if (position == mCursorViews.size() - 1 || position == 0) {
					if (position == 0) {
						mFacialViewPager.setCurrentItem(position + 1);// 第二屏 会再次实现该回调方法实现跳转.
						mCursorViews.get(1).setBackgroundResource(R.drawable.facial_cursor_selected);
					} else {
						mFacialViewPager.setCurrentItem(position - 1);// 倒数第二屏
						mCursorViews.get(position - 1).setBackgroundResource(
								R.drawable.facial_cursor_selected);
					}
				}
			}
			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {
			}
			@Override
			public void onPageScrollStateChanged(int arg0) {
			}
		});

	}

	/**
	 * 绘制游标背景
	 */
	private void drawCursor(int index) {
		for (int i = 1; i < mCursorViews.size(); i++) {
			if (index == i) {
				mCursorViews.get(i).setBackgroundResource(R.drawable.facial_cursor_selected);
			} else {
				mCursorViews.get(i).setBackgroundResource(R.drawable.facial_cursor_normal);
			}
		}
	}
	
	
    
    /** 隐藏软键盘 */
	private void hideKeyBoard() {
		if(mContext != null)
		{
			((InputMethodManager) mContext.getSystemService(Context.INPUT_METHOD_SERVICE))
					.hideSoftInputFromWindow(mMsgEdit.getWindowToken(),
						InputMethodManager.HIDE_NOT_ALWAYS);
		}
	}
	
	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.facial_enable://表情选择
			/*
			 * 让编辑框同时获得焦点
			 * 否则，如果先点击表情框，再点击编辑框，表情框不会消失。
			 * 因为编辑框只有获得焦点之后，才能进行监听操作
			 */
			mMsgEdit.setFocusable(true);
			mMsgEdit.setFocusableInTouchMode(true);
			mMsgEdit.requestFocus();
			// 显示或隐藏表情选择框
			if (mFacialLayout.getVisibility() == View.VISIBLE) {
				mFacialEnable.setImageDrawable(getResources().getDrawable(R.drawable.facial_btn_normal));
				mFacialLayout.setVisibility(View.GONE);
			} else {
				mFacialEnable.setImageDrawable(getResources().getDrawable(R.drawable.facial_btn_enable));
				//隐藏软键盘
				hideKeyBoard();
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				mFacialLayout.setVisibility(View.VISIBLE);
			}
			break;
		case R.id.facial_edit://编辑框
			// 隐藏表情选择框
			if (mFacialLayout.getVisibility() == View.VISIBLE) {
				mFacialEnable.setImageDrawable(getResources().getDrawable(R.drawable.facial_btn_normal));
				mFacialLayout.setVisibility(View.GONE);
			} 
			break;
		case R.id.facial_sendBtn://发送按钮
			String input = mMsgEdit.getText().toString();
			if(input.isEmpty())
				return;
			
			if(mSendBtnListener!=null)
			{
				//调用按钮监听
				mSendBtnListener.onBtnClicked(input);
			}
			break;
		}
	}

	/**
	 * 监听表情选择
	 */
	@Override
	public void onItemClick(AdapterView<?> arg0, View view, int position, long arg3) {
		SmileyFacial smiley = (SmileyFacial) mFacialAdapters.get(current).getItem(position);
		if (smiley.getId() == R.drawable.facial_del_selector) {//删除按钮
			int selection = mMsgEdit.getSelectionStart();
			String text = mMsgEdit.getText().toString();
			if (selection > 0) {
				String str = text.substring(selection - 1);
				if ("]".equals(str)) {//最后一个是表情符
					int start = text.lastIndexOf("[");
					int end = selection;
					mMsgEdit.getText().delete(start, end);
					
				}else//正常字符
				{
					mMsgEdit.getText().delete(selection - 1, selection);
				}
			}
		}
		if (!TextUtils.isEmpty(smiley.getCharacter())) {//选择表情
			SpannableString spannableString = FacialUtils.getInstace()
					.addFacial(getContext(), smiley.getId(), smiley.getCharacter());
			//将表情显示在编辑框中
			mMsgEdit.append(spannableString);
			Log.d("vaint", "文本框输出 "+ mMsgEdit.getText().toString());
		}

	}
	
	
}
