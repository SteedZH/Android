package vaint.wyt.view;

import java.util.List;

import vaint.wyt.R;
import vaint.wyt.bean.SmileyFacial;
import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class FacialAdapter extends BaseAdapter {

	private List<SmileyFacial> mDataList;

	private LayoutInflater mInflater;
	
	private Context mContext;
	private int mHeight;
	private int mWidth;

	private int size = 0;

	public FacialAdapter(Context context, List<SmileyFacial> list, int width, int height) {
		mContext = context;
		mWidth = width;
		mHeight = height;
		mInflater = LayoutInflater.from(mContext);
		mDataList = list;
		this.size = list.size();
	}

	@Override
	public int getCount() {
		return this.size;
	}

	@Override
	public Object getItem(int position) {
		return mDataList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View view, ViewGroup parent) {
		SmileyFacial smiley = mDataList.get(position);
		ViewHolder viewHolder = null;
		if (view == null) {
			viewHolder = new ViewHolder();
			view = mInflater.inflate(R.layout.viewpage_item_facial, null);
			 /*
	         * 设置表情框的高度
	         * 如果使用getLayoutParams(),由于控件的View还没有出现，会返回null
	         * 下面的方法，是根据父布局是LinearLayout，如果是其他布局，要相应改变
	         */
			LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(new LayoutParams(mWidth, mHeight));
			viewHolder.tvLayout = (LinearLayout) view.findViewById(R.id.facial_itemLayout);
			viewHolder.tvFacial = (ImageView) view.findViewById(R.id.facial_itemImage);
			//设置每个表情的宽高
			viewHolder.tvLayout.setLayoutParams(lp);
			view.setTag(viewHolder);
		} else {
			viewHolder = (ViewHolder) view.getTag();
		}
		if (smiley.getId() == R.drawable.facial_del_selector) {
			view.setBackgroundDrawable(null);
			viewHolder.tvFacial.setImageResource(smiley.getId());
		} else if (TextUtils.isEmpty(smiley.getCharacter())) {
			view.setBackgroundDrawable(null);
			viewHolder.tvFacial.setImageDrawable(null);
		} else {
			viewHolder.tvFacial.setTag(smiley);
			viewHolder.tvFacial.setImageResource(smiley.getId());
		}

		return view;
	}

	class ViewHolder {
		public LinearLayout tvLayout;
		public ImageView tvFacial;
	}
}