package vaint.wyt.view;

import java.util.List;

import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;

public class ViewPagerAdapter extends PagerAdapter {

    private List<View> pageViews;

    public ViewPagerAdapter(List<View> pageViews) {
        super();
        this.pageViews=pageViews;
    }

    // 显示数目
    @Override
    public int getCount() {
        return pageViews.size();
    }

    @Override
    public boolean isViewFromObject(View view, Object obj) {
        return view == obj;
    }

    @Override
    public int getItemPosition(Object object) {
        return super.getItemPosition(object);
    }

    @Override
    public void destroyItem(View view, int position, Object obj) {
        ((ViewPager)view).removeView(pageViews.get(position));
    }

    /***
     * 获取每一个item.类于listview中的getview
     */
    @Override
    public Object instantiateItem(View view, int position) {
        ((ViewPager)view).addView(pageViews.get(position));
        return pageViews.get(position);
    }
}
