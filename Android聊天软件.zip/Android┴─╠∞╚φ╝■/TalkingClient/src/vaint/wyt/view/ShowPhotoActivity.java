package vaint.wyt.view;

import vaint.wyt.R;
import vaint.wyt.constant.Constants;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.MotionEvent;
import android.widget.ImageView;

public class ShowPhotoActivity extends Activity {

	private ImageView mShowPhoto;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_show_photo);
		
		mShowPhoto = (ImageView) findViewById(R.id.showPhotoImage);
		Intent intent = getIntent();
		Bitmap bmp = (Bitmap) intent.getParcelableExtra(Constants.Flags.SHOW_PHOTO);
		if(bmp != null)
		{
			mShowPhoto.setImageDrawable(new BitmapDrawable(bmp));
		}
	}

	@Override
    public boolean onTouchEvent(MotionEvent event) {
        finish();
        return true;
    }
}
