package vaint.wyt.view;

import java.util.List;

import vaint.wyt.R;
import vaint.wyt.bean.ChatListModel;
import vaint.wyt.msg.FacialUtils;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.SpannableString;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class ChatListAdapter extends BaseAdapter{
	private List<ChatListModel> mList = null;
	private Context mContext;
	
	public ChatListAdapter(Context context, List<ChatListModel> list) {
		mContext = context;
		mList = list;
	}
	
	/**
	 * 当ListView数据发生变化时,调用此方法来更新ListView
	 * @param list
	 */
	public void updateListView(List<ChatListModel> list){
		mList = list;
//		notifyDataSetInvalidated();
		notifyDataSetChanged();
	}

	public int getCount() {
		return mList.size();
	}

	public Object getItem(int position) {
		return mList.get(position);
	}

	public long getItemId(int position) {
		return position;
	}

	public View getView(final int position, View view, ViewGroup arg2) {
		ViewHolder viewHolder = null;
		final ChatListModel model = mList.get(position);
		if (view == null) {
			viewHolder = new ViewHolder();
			view = LayoutInflater.from(mContext).inflate(R.layout.listview_item_chat, null);
			viewHolder.tvPhoto = (ImageView) view.findViewById(R.id.chat_photo);
			viewHolder.tvTitle = (TextView) view.findViewById(R.id.chat_title);
			viewHolder.tvUnRead = (TextView) view.findViewById(R.id.chat_unreadTips);
			viewHolder.tvContent = (TextView) view.findViewById(R.id.chat_content);
			viewHolder.tvTime = (TextView) view.findViewById(R.id.chat_time);
			view.setTag(viewHolder);
		} else {
			viewHolder = (ViewHolder) view.getTag();
		}
		
		Drawable drawable = model.getPhoto();
		if(drawable != null)
		{
			viewHolder.tvPhoto.setImageDrawable(drawable);
		}
		else
		{
			viewHolder.tvPhoto.setImageDrawable(mContext.getResources().getDrawable(R.drawable.photo_default));
		}
		
		//未读消息
		if(model.getUnread() > 0)
		{
			viewHolder.tvUnRead.setText(model.getUnread() + "");
			viewHolder.tvUnRead.setVisibility(View.VISIBLE);
		}else
		{
			//隐藏未读消息提示 如果没有这句，即使Layout中该属性为gone，但是还是不能隐藏提示
			viewHolder.tvUnRead.setVisibility(View.GONE);
		}
		viewHolder.tvTitle.setText(model.getTitle());
		SpannableString span = FacialUtils.getInstace().showFacial(mContext, model.getContent());
		viewHolder.tvContent.setText(span);
		viewHolder.tvTime.setText(model.getTime());
		
		return view;
	}
	


	final static class ViewHolder {
		ImageView tvPhoto;
		TextView tvTitle;
		TextView tvUnRead;
		TextView tvContent;
		TextView tvTime;
	}

}