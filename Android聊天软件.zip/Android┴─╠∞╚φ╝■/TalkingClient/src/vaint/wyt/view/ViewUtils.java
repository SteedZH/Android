package vaint.wyt.view;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

import vaint.wyt.R;
import vaint.wyt.encrypt.Base64Coder;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;

public class ViewUtils {	
	/** 圆形进度条 */
	private static ProgressDialog mProDialog;
	/***/
	

	/** 显示圆形进度条 */
	public static void ShowProgressDialog(Context ctx, String msg) {
		mProDialog = new ProgressDialog(ctx);
		mProDialog.setMessage(msg);
		mProDialog.setCancelable(false);
		mProDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
		mProDialog.show();
	}
	/** 显示的圆形进度条 */
	public static void ShowProgressDialog(Context ctx, String msg, boolean cancel) {
		mProDialog = new ProgressDialog(ctx);
		mProDialog.setMessage(msg);
		mProDialog.setCancelable(cancel);
		mProDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
		mProDialog.show();
	}

	/** 隐藏圆形进度条 */
	public static void HideProgressDialog() {
		if (mProDialog != null && mProDialog.isShowing()) {
			mProDialog.dismiss();
			mProDialog = null;
		}
	}

	/** 提示用户网络连接超时 */
	public static void ShowConnectTimeoutDialog(Context ctx) {
		new AlertDialog.Builder(ctx).setMessage(R.string.dialog_msg_conn_timeout)
				.setPositiveButton(R.string.btn_ok, null).show();
	}
	
	/** 提示用户系统繁忙 */
	public static void ShowSystemBusyDialog(Context ctx)
	{
		new AlertDialog.Builder(ctx).setMessage(R.string.dialog_msg_system_busy)
			.setPositiveButton(R.string.btn_ok, null).show();
	}
	
	/** 提示用户错误信息 */
	public static void ShowErrorDialog(Context ctx, String msg) {
		if(msg== null || msg.isEmpty())
			return;
		
		new AlertDialog.Builder(ctx).setMessage(msg)
				.setPositiveButton(R.string.btn_ok, null).show();
	}
	
	/**
	 * 将照片存储为字符串形式(经过BASE64编码)
	 * 
	 * @param bmp
	 * @return
	 */
	public static String DrawableToString(Drawable drawable) {
		if(drawable == null)
		{
			return "";
		}
		BitmapDrawable bd = (BitmapDrawable)drawable;
		Bitmap bmp = bd.getBitmap();
		if(bmp == null)
			return "";
		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		//压缩图片
		bmp.compress(Bitmap.CompressFormat.PNG, 60, stream);
		byte[] b = stream.toByteArray();
		// 将图片流以字符串形式存储下来
		return Base64Coder.encodeLines(b);
	}

	/**
	 * 将Base64Coder编码后的字符串转换为Drawable
	 * 
	 * @param encodeStr
	 * @return
	 */
	public static Drawable StringToDrawable(String encodeStr) {
		if(encodeStr==null || encodeStr.isEmpty())
		{
			return null;
		}
		//Base64Coder解码
		ByteArrayInputStream in = new ByteArrayInputStream(Base64Coder.decodeLines(encodeStr));
		Bitmap dBitmap = BitmapFactory.decodeStream(in);
		Drawable drawable = new BitmapDrawable(dBitmap);
		return drawable;
	}
	
	
}
