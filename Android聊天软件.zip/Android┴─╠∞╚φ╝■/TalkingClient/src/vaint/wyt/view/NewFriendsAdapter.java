package vaint.wyt.view;

import java.util.List;

import vaint.wyt.R;
import vaint.wyt.bean.ChatData;
import vaint.wyt.bean.ChatData.Type;
import vaint.wyt.bean.NewFriendsModel;
import vaint.wyt.bean.User;
import vaint.wyt.constant.Constants;
import vaint.wyt.db.CacheUtils;
import vaint.wyt.db.DataUtils;
import vaint.wyt.msg.MsgUtils;
import vaint.wyt.msg.ThreadUtils;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class NewFriendsAdapter  extends BaseAdapter{
	private List<NewFriendsModel> mList = null;
	private Context mContext;
	private ViewHolder mViewHolder;
	private Handler mMultiHandler;
	
	Handler mHandler = new Handler();
	
	public NewFriendsAdapter(Context context, List<NewFriendsModel> list) {
		mContext = context;
		mList = list;
		mMultiHandler = ThreadUtils.GetMultiHandler(NewFriendsAdapter.class.getSimpleName());
	}
	
	
	public void updateListView(List<NewFriendsModel> list){
		mList = list;
		notifyDataSetChanged();
	}

	public int getCount() {
		return mList.size();
	}

	public Object getItem(int position) {
		return mList.get(position);
	}

	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(final int position, View view, ViewGroup arg2) {
		final NewFriendsModel model = mList.get(position);
		if (view == null) {
			mViewHolder = new ViewHolder();
			view = LayoutInflater.from(mContext).inflate(R.layout.listview_item_new_friends, null);
			mViewHolder.tvPhoto = (ImageView) view.findViewById(R.id.newFriends_photo);
			mViewHolder.tvName = (TextView) view.findViewById(R.id.newFriends_name);
			mViewHolder.tvGender = (ImageView) view.findViewById(R.id.newFriends_gender);
			mViewHolder.tvTime = (TextView) view.findViewById(R.id.newFriends_time);
			mViewHolder.tvVerifyMsg = (TextView) view.findViewById(R.id.newFriends_verifyMsg);
			mViewHolder.tvAgreeTxt = (TextView) view.findViewById(R.id.newFriends_agreeTxt);
			mViewHolder.tvAgreeBtn = (Button) view.findViewById(R.id.newFriends_agreeBtn);
			view.setTag(mViewHolder);
		} else {
			mViewHolder = (ViewHolder) view.getTag();
		}
		Drawable drawable = model.getPhoto();
		if(drawable != null)
		{
			mViewHolder.tvPhoto.setImageDrawable(drawable);
		}
		if(Constants.Gender.FEMALE.equals(model.getGender()))
		{
			mViewHolder.tvGender.setImageDrawable(mContext.getResources().getDrawable(R.drawable.gender_female));
		}
		if(model.isAgreed())
		{
			mViewHolder.tvAgreeBtn.setVisibility(View.GONE);
			mViewHolder.tvAgreeTxt.setVisibility(View.VISIBLE);
		}else
		{
			mViewHolder.tvAgreeBtn.setVisibility(View.VISIBLE);
			mViewHolder.tvAgreeTxt.setVisibility(View.GONE);
			mViewHolder.tvAgreeBtn.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					final ChatData.MSG msg = new ChatData.MSG();
					msg.setType(Type.ADD_AGREE);
					msg.setFromId(CacheUtils.GetUserId());
					msg.setName(CacheUtils.GetUserName());
					msg.setPhoto(ViewUtils.DrawableToString(CacheUtils.GetUserPhoto()));
					msg.setToId(model.getUserId());
					
					mViewHolder.tvAgreeBtn.setVisibility(View.GONE);
					mViewHolder.tvAgreeTxt.setVisibility(View.VISIBLE);
					mViewHolder.tvTime.setText(MsgUtils.GetFormatTime());
					
					mMultiHandler.post(new Runnable() {
						public void run() {
							//发送同意添加好友的消息
							MsgUtils.SendMsg(msg);
							
							//更新好友请求列表数据
							mList.remove(position);
							model.setAgreed(true);
							mList.add(position, model);
							DataUtils.UpdateNewFriendsList(mList);
							
							User user = new User();
							user.setUserId(model.getUserId());
							user.setName(model.getName());
							user.setPhoto(model.getPhotoString());
							//更新好友列表
							DataUtils.AddFriend(user);
						}
					});
				}
			});
		}
		
		mViewHolder.tvName.setText(model.getName());
		mViewHolder.tvTime.setText(model.getTime());
		mViewHolder.tvVerifyMsg.setText(model.getVerifyMsg());
		
		return view;
	}

	
	final static class ViewHolder {
		ImageView tvPhoto;
		TextView tvName;
		ImageView tvGender;
		TextView tvTime;
		TextView tvVerifyMsg;
		Button tvAgreeBtn;
		TextView tvAgreeTxt;
	}
	
}
