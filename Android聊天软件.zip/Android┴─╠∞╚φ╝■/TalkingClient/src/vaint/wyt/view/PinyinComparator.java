package vaint.wyt.view;

import java.util.Comparator;

import vaint.wyt.bean.ContactsModel;

/**
 *昵称首字母排序
 */
public class PinyinComparator implements Comparator<ContactsModel> {

	public int compare(ContactsModel o1, ContactsModel o2) {
		if (o1.getSortLetters().equals("@")
				|| o2.getSortLetters().equals("#")) {
			return -1;
		} else if (o1.getSortLetters().equals("#")
				|| o2.getSortLetters().equals("@")) {
			return 1;
		} else {
			return o1.getSortLetters().compareTo(o2.getSortLetters());
		}
	}

}
